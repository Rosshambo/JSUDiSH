import javax.speech.*;
import javax.speech.recognition.*;
import com.cloudgarden.speech.CGResult;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

public class DaveResultListener extends ResultAdapter {
    private Recognizer rec;
	static RuleGrammar activeGrammar;
	static RuleGrammar tempGrammar;
	static Vector sentences;
	static Vector grammars;
	static Vector grammarSizes;
	static Vector theWholeParagraph;	

	StudyPal parent;
	int movementByUpdater = 0;
	int currentGrammarSet = 0;
	int currentGrammar = -1;
	int currentWordInSentence = 0;
	int currentWordInParagraph = 0;
	
	public DaveResultListener(Recognizer rec, StudyPal parent, String filename) {
        this.rec = rec;
		this.parent = parent;
		parseInputFile(filename);
    }
    
	public void parseInputFile(String filename) {
		File inputFile;
		Scanner s;
		try {
			inputFile = new File(filename);
			theWholeParagraph = new Vector();
			sentences = new Vector();
			grammars = new Vector();
			grammarSizes = new Vector();			
			s = new Scanner(inputFile).useDelimiter("\\.");
			
			while (s.hasNext()) {
				sentences.addElement(s.next());
			}	
			
			for (Object sentence : sentences) {
				int grammarsAddedSincePeriod = 0;
				Vector currentSentence = new Vector();
				Scanner tempScan = new Scanner((String)sentence);

				while (tempScan.hasNext()) {
					while  (tempScan.hasNext()) {
						String tempWord = tempScan.next();
						currentSentence.addElement(tempWord);
						theWholeParagraph.addElement(tempWord);
					}	
					Vector phrases = new Vector();
					String grammar = "";
					String wordString = "";
					String phrase = "";				
					int beginning = 0;
					int marker = beginning;
					while (beginning < currentSentence.size()) {
						marker = beginning;
						phrase = "";
						while (marker < currentSentence.size())  {	

							wordString += " " + String.valueOf(currentSentence.get(marker));
							phrase = wordString + " {" + String.valueOf(marker+1) + "} ";
//							System.out.println("phrase: " + phrase);

							if (marker + 1 == currentSentence.size()) {
								phrase += " {last} ";
							}
		
							phrases.addElement(phrase);
							if (marker + 1 == currentSentence.size()) {
	//							System.out.println("time to make grammar?");
								for (int i=0; i<phrases.size(); i++) {
									String tempPhrase = (String)phrases.get(i);
									//System.out.println("tempPhrase: " + tempPhrase);
									grammar += tempPhrase;
									if (i < phrases.size()-1) {
										grammar += "| ";
									}
								}
								
								//cut the grammar
//								System.out.println("\n #########grammar is " + grammar);
								grammarsAddedSincePeriod += 1;
								tempGrammar = rec.newRuleGrammar(String.valueOf(grammars.size()));
								tempGrammar.setRule("phrase", tempGrammar.ruleForJSGF(grammar), true);	
								tempGrammar.setEnabled(false);
								grammars.addElement(tempGrammar);
								System.out.println("grammar size is " + grammars.size());
								beginning += 1;
								marker = beginning;
								grammar = "";
								wordString = "";
								phrases.clear();
							}								
								//end of cutting grammar
							else {
								marker +=1;
							}
							phrase = "";

						} //end while (marker < currentSentence.size()) {
						wordString = "";
					} //end while (beginning < currentSentence.size()) {
					
					currentSentence.clear();
					grammarSizes.addElement(grammarsAddedSincePeriod);
					System.out.println("there were " + grammarSizes.get(grammarSizes.size()-1) + " grammars in that sentence");
					grammarsAddedSincePeriod = 0;
				}	//end of while that splits sentences
				
			}
			nextGrammar(1);
        } 
		catch(GrammarException e) {  System.out.println("crap grammar");    } 	
		catch(Exception e) {  e.printStackTrace(System.out);    } 	
	} //end of parseInputFile
	
	public void nextGrammar(int shift) {
		parent.suspend();
		System.out.println("moving to next grammar");
		try {
//			RuleGrammar tempGram;
			if (currentGrammar == -1) {
				
				int tempGramSize = Integer.parseInt(String.valueOf(grammarSizes.get(currentGrammarSet)));
				for (int i=0;i<tempGramSize; i++) {
					System.out.println("********* enabling grammar number " + String.valueOf(currentGrammar + 1));
					activeGrammar = rec.getRuleGrammar(String.valueOf(currentGrammar+1));
					activeGrammar.setEnabled(true);
					currentGrammar += 1;					
				}

			}
			else {
				//disable previous grammars
				int tempGramSize = Integer.parseInt(String.valueOf(grammarSizes.get(currentGrammarSet-1)));
				for (int i=0;i<tempGramSize; i++) {
					System.out.println("********* disabling grammar number " + String.valueOf(currentGrammar - i +1));
					activeGrammar = rec.getRuleGrammar(String.valueOf(currentGrammar - i+1));
					activeGrammar.setEnabled(false);
				}
				//enable current grammars
				tempGramSize = Integer.parseInt(String.valueOf(grammarSizes.get(currentGrammarSet)));
				for (int i=0;i<tempGramSize; i++) {
					System.out.println("********* enabling grammar number " + String.valueOf(currentGrammar+1));
					activeGrammar = rec.getRuleGrammar(String.valueOf(currentGrammar+1));
					activeGrammar.setEnabled(true);
					currentGrammar += 1;					
				}
			}
			currentGrammarSet += 1;
//			System.out.println("active grammar is number: " + currentGrammar + ", which has the following phrases: " + tempGram.getRule("phrase").toString());
			rec.commitChanges();
			rec.waitEngineState(rec.LISTENING);
			parent.resume();
		} catch (Exception e) {	e.printStackTrace(System.out); }
	} //end of nextGrammar
	
    public void resultRejected(ResultEvent e) {
        Result r = (Result)(e.getSource());
//		nextGrammar(movementByUpdater);
//		System.out.println("movementByUpdater zeroed");
		movementByUpdater = 0;
//        System.out.println("##################Result Rejected "+r);
    }
    public void resultCreated(ResultEvent e) {
        Result r = (Result)(e.getSource());
        System.out.println("Result Created ");
    }
    public void resultUpdated(ResultEvent e) {
        Result r = (Result)(e.getSource());
//        System.out.println("Result Updated... "+r);
		ResultToken [] tokens = r.getBestTokens();
		
		if(tokens != null && tokens.length > 0) {
			
			//if true, we've received a finalized utterance (we've heard silence)
			if (r.getResultState() != Result.UNFINALIZED) {
				String tags[] = null;
				tags = ((FinalRuleResult)r).getTags();
				
				//stolen
					String tempString;
					tempString = tokens[0].getWrittenText();
					
					//how to move forward
					String tempString2 = (String)theWholeParagraph.get(currentWordInParagraph);
					tempString.trim();
					tempString2.trim();
					System.out.println("finalized: last word you said: <" + tempString + ">");
					System.out.println("finalized: next word i expect: <" + tempString2 + ">");		
					if (tempString.compareTo(tempString2) == 0) {
						System.out.println("finalized: we can move ahead one!");
						movementByUpdater += 1;
						parent.moveReadMarker(1);
						currentWordInSentence += 1;
						currentWordInParagraph += 1;	
					}
					//end of how to move forward
				
				//end stolen
				
				
				
				//System.out.println("this is last update, check if end of sentence");
				if (tags != null && tags.length > 1) {
					currentWordInSentence = 0;
					nextGrammar(1);
				}
			}
			else {
				int tempCounter = movementByUpdater;
//				while (movementByUpdater < tokens.length) {
				while (tempCounter < tokens.length) {

					String tempString;
					tempString = tokens[tempCounter].getWrittenText();
					tempCounter += 1;					
					//how to move forward
					String tempString2 = (String)theWholeParagraph.get(currentWordInParagraph);
					tempString.trim();
					tempString2.trim();
					System.out.println("update: last word you said: <" + tempString + ">");
					System.out.println("update: next word i expect: <" + tempString2 + ">");		
					if (tempString.compareTo(tempString2) == 0) {
						System.out.println("update: we can move ahead one!");
						movementByUpdater += 1;
						parent.moveReadMarker(1);
						currentWordInSentence += 1;
						currentWordInParagraph += 1;	
					}
					//end of how to move forward
				} //end of while	

			} //end of else
		} //end of if there are any tokens
	} //end resultupdated
    
	public void moveAheadByOne() {
		movementByUpdater += 1;
		parent.moveReadMarker(1);
		currentWordInSentence += 1;
		currentWordInParagraph += 1;	

//		nextGrammar(movementByUpdater);
		movementByUpdater = 0;		
	} //end moveAheadByOne
	
    public  void resultAccepted(ResultEvent e) {
//		System.out.println("Result Accepted");
        final FinalResult r = (FinalResult)(e.getSource());		
		//nextGrammar(movementByUpdater);
		movementByUpdater = 0;
		
        Runnable lt = new Runnable() {
            public void run() {
                try {
      //              System.out.print("Result Accepted: "+r);
                    ResultToken tokens[] = null;
					String tags[] = null;

                    if(r.getGrammar() instanceof RuleGrammar) {
                        tokens = ((FinalRuleResult)r).getAlternativeTokens(0);
						tags = ((FinalRuleResult)r).getTags();				
						
	//					System.out.println("\n $$$$$$$$$$ tag: " + tags[0] + " sentence: " + currentWordInSentence);
						int tagNumber = Integer.parseInt(tags[0]);
		
				//begin logic from updated
/*				
						String tempString;
						tempString = tokens[tokens.length-1].getWrittenText();
						
						//how to move forward
						String tempString2 = (String)theWholeParagraph.get(currentWordInParagraph);
						tempString.trim();
						tempString2.trim();
						System.out.println("accepted: last word you said: <" + tempString + ">");
						System.out.println("accepted: next word i expect: <" + tempString2 + ">");		
						if (tempString.compareTo(tempString2) == 0) {
							System.out.println("accepted: we can move ahead one!");
							movementByUpdater += 1;
							parent.moveReadMarker(1);
							currentWordInSentence += 1;
							currentWordInParagraph += 1;	
						}
*/						
				//end logic from updated
		
		
		
						//must ensure we're not skipping
						if (tagNumber > 0 && tokens.length == tagNumber - currentWordInSentence) { 
							//System.out.println("moving ahead " + String.valueOf(tagNumber - currentWordInSentence) + " spaces");
							//parent.moveReadMarker(tagNumber - currentWordInSentence);
							//nextGrammar(tagNumber - currentWordInSentence);
							currentWordInSentence = tagNumber;
//							currentWordInParagraph += tokens.length;
							
							//now, do we move to the next grammar?
							if (tags.length > 1) {
								//System.out.println("second tag is " + tags[1]);
//								nextGrammar(1);
	//							currentWordInSentence = 0;								
							}	
						}
						
						String rule = ((FinalRuleResult)r).getRuleName(0);
						String word = "";						
						for (int i = 0; i<tokens.length; i++) {
							word += tokens[i].getWrittenText() + " ";							
						}
						word = word.trim();
						//System.out.println ("you said: " + word);
                    } 
                                        
                } catch(Exception e1) {
                    e1.printStackTrace(System.out);
                } catch(ResultStateError er) {
                    er.printStackTrace(System.out);
                }
            }
        };
        (new Thread(lt)).start();
        
    }
}