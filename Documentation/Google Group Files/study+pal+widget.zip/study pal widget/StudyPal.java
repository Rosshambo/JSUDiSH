import com.cloudgarden.speech.userinterface.*;
import javax.speech.*;
import javax.speech.recognition.*;
import java.io.*;
import java.net.*;
import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;

public class StudyPal extends JPanel implements ActionListener {
    static Recognizer rec = null;
	static DaveResultListener drl;
//    JTextField textField;
    JTextArea textArea;
	JButton skipWord;
	int currentWord = 0;
	int currentLocation  = 0;
	Vector words;
	Font myFont;
	
	public StudyPal(String filename) {
        super(new GridBagLayout());
		setPreferredSize(new Dimension(650, 400));
		skipWord = new JButton("Skip Word");
		skipWord.addActionListener(this);
		
	//	textField = new JTextField("nothing yet");
        textArea = new JTextArea(5, 20);
        textArea.setEditable(false);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setMargin(new Insets(10, 10, 10, 10));
		myFont = new Font("Verdana", Font.PLAIN, 16);
		textArea.setFont(myFont);
		parseInputFile(filename);
        JScrollPane scrollPane = new JScrollPane(textArea);

        //Add Components to this panel.
        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;

        c.fill = GridBagConstraints.HORIZONTAL;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;
        this.add(scrollPane, c);
		this.add(skipWord);
		//this.add(textField);
	} //end of constructor

	public void actionPerformed(ActionEvent e) {
		drl.moveAheadByOne();
	} //end actionPerformed
	
	public void suspend() {
		System.out.println("suspending");
		textArea.setForeground(Color.LIGHT_GRAY);
	//	textField.setText("processing");
		this.paintImmediately(textArea.getBounds());
	}
	
	public void resume() {
		System.out.println("resuming");	
		textArea.setForeground(Color.BLACK);
//		textField.setText("ready");
		this.paintImmediately(textArea.getBounds());
	}
	
	public void parseInputFile(String filename) {
		File inputFile;
		Scanner s;
		try {
			inputFile = new File(filename);
			words = new Vector();
			s = new Scanner(inputFile);

			while (s.hasNext()) {
				words.addElement(s.next() + " ");
			}
			
        } catch(Exception e) {
            e.printStackTrace(System.out);
        } 	
		
		for(Object o : words) {
			textArea.append(String.valueOf(o));
		}
		textArea.setCaretPosition(0);
	} //end of parseInputFile
	
	public void moveReadMarker(int numWords) {
		for (int i = 0; i < numWords; i++) {
			currentLocation += (String.valueOf(words.get(currentWord + i))).length();
		}
		
		currentWord += numWords;
		try { 	textArea.setCaretPosition(currentLocation + 200); }
		catch (IllegalArgumentException e) {	System.out.println("caret tried to go too far");	}

		try {
			Highlighter hl = textArea.getHighlighter();
			hl.removeAllHighlights();
			hl.addHighlight(0, currentLocation, DefaultHighlighter.DefaultPainter);
		} catch (javax.swing.text.BadLocationException e) { System.out.println("error: " + e); }
    }


	public static void createAndShowGUI(String filename) {
        //Create and set up the window.
        JFrame frame = new JFrame("TextDemo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Add contents to the window.
		StudyPal pal = new StudyPal(filename);
        frame.add(pal);
        //Display the window.
        frame.pack();
        frame.setVisible(true);
		setupSpeech(pal, filename);
    }

	public static void setupSpeech(StudyPal parent, String filename) {
		try {			
			SpeechEngineChooser chooser = SpeechEngineChooser.getRecognizerDialog();
			chooser.show();
			RecognizerModeDesc desc = chooser.getRecognizerModeDesc();
			
			rec = Central.createRecognizer(desc);
			rec.addEngineListener(new TestEngineListener());
			RecognizerAudioAdapter raud = new TestAudioListener();
			rec.getAudioManager().addAudioListener(raud);
			
			rec.allocate();
			rec.waitEngineState(Recognizer.ALLOCATED);
			drl = new DaveResultListener(rec, parent, filename);
			rec.addResultListener(drl);
			RecognizerProperties props = rec.getRecognizerProperties();
			props.setNumResultAlternatives(5);
			props.setResultAudioProvided(true);
			
			rec.commitChanges();
			rec.waitEngineState(rec.LISTENING);
			System.out.println("\nUsing engine "+rec.getEngineModeDesc());
			
			rec.requestFocus();
			rec.resume();            
			rec.waitEngineState(Recognizer.DEALLOCATED);            
		
		} catch(Exception e) {
			e.printStackTrace(System.out);
		} catch(Error e1) {
			e1.printStackTrace(System.out);
		} finally {
			try {
				rec.deallocate();
			} catch(Exception e2) {
				e2.printStackTrace(System.out);
			}
			System.exit(0);
		}
	} //end setupSpeech
	
    public static void main(String[] args) {
		final String filename = args[0];
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI(filename);
            }
        });
	
	} //end main
} //end class