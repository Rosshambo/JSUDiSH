import javax.speech.*;
import javax.speech.recognition.*;
import com.cloudgarden.speech.CGResult;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

public class DaveResultListener extends ResultAdapter {
    private Recognizer rec;
	static RuleGrammar activeGrammar;
	static RuleGrammar tempGrammar;
	static Vector sentences;
	static Vector grammars;
	static Vector grammarSizes;
	static Vector theWholeParagraph;	

	StudyPal parent;
	int movementByUpdater = 0;
	int currentGrammarSet = 0;
	int currentGrammar = -1;
	int currentWordInSentence = 0;
	int currentWordInParagraph = 0;
	
	//time stuff
	boolean hasStoppedReading = false;
	int secondsElapsed = 0;
	java.util.Timer timer;
	
	TimerTask task = new TimerTask() {
			public void run() {
				secondsElapsed += 1;
				System.out.println( "///////////////////// i'm in the task, and it's been " + secondsElapsed + " seconds");
				if (!hasStoppedReading && secondsElapsed > 5) {
					System.out.println( "///////////////////// you have stopped reading! ");				
					hasStoppedReading = true;
					parent.fireStudyPalEvent(2);	
				}
			}
		}; //end timer task

	public DaveResultListener(Recognizer rec, StudyPal parent, String filename) {
	    timer = new java.util.Timer();
		timer.scheduleAtFixedRate(task, 4000, 1000);
		
        this.rec = rec;
		this.parent = parent;
		parseInputFile(filename);
    }
    
	public int getNumWordsRead() {
		return currentWordInParagraph;
	} //end getNumWordsRead
	
	public void parseInputFile(String filename) {
		File inputFile;
		Scanner s;
		try {
			inputFile = new File(filename);
			theWholeParagraph = new Vector();
			sentences = new Vector();
			grammars = new Vector();
			grammarSizes = new Vector();			
			s = new Scanner(inputFile).useDelimiter("\\.");
			
			while (s.hasNext()) {
				sentences.addElement(s.next());
			}	
			
			for (Object sentence : sentences) {
				int grammarsAddedSincePeriod = 0;
				Vector currentSentence = new Vector();
				Scanner tempScan = new Scanner((String)sentence);

				while (tempScan.hasNext()) {
					while  (tempScan.hasNext()) {
						String tempWord = tempScan.next();
						currentSentence.addElement(tempWord);
						theWholeParagraph.addElement(tempWord);
					}	
					Vector phrases = new Vector();
					String grammar = "";
					String wordString = "";
					String phrase = "";				
					int beginning = 0;
					int marker = beginning;
					while (beginning < currentSentence.size()) {
						marker = beginning;
						phrase = "";
						while (marker < currentSentence.size())  {	

							wordString += " " + String.valueOf(currentSentence.get(marker));
							phrase = wordString + " {" + String.valueOf(marker+1) + "} ";
//							System.out.println("phrase: " + phrase);

							if (marker + 1 == currentSentence.size()) {
								phrase += " {last} ";
							}
		
							phrases.addElement(phrase);
							if (marker + 1 == currentSentence.size()) {
	//							System.out.println("time to make grammar?");
								for (int i=0; i<phrases.size(); i++) {
									String tempPhrase = (String)phrases.get(i);
									//System.out.println("tempPhrase: " + tempPhrase);
									grammar += tempPhrase;
									if (i < phrases.size()-1) {
										grammar += "| ";
									}
								}
								
								//cut the grammar
								//System.out.println("\n #########grammar is " + grammar);
								grammarsAddedSincePeriod += 1;
								tempGrammar = rec.newRuleGrammar(String.valueOf(grammars.size()));
								tempGrammar.setRule("phrase", tempGrammar.ruleForJSGF(grammar), true);	
								tempGrammar.setEnabled(false);
								grammars.addElement(tempGrammar);
								System.out.println("grammar size is " + grammars.size());
								beginning += 1;
								marker = beginning;
								grammar = "";
								wordString = "";
								phrases.clear();
							}								
								//end of cutting grammar
							else {
								marker +=1;
							}
							phrase = "";

						} //end while (marker < currentSentence.size()) {
						wordString = "";
					} //end while (beginning < currentSentence.size()) {
					
					currentSentence.clear();
					grammarSizes.addElement(grammarsAddedSincePeriod);
					System.out.println("there were " + grammarSizes.get(grammarSizes.size()-1) + " grammars in that sentence");
					grammarsAddedSincePeriod = 0;
				}	//end of while that splits sentences
				
			}
			nextGrammar(1);
        } 
		catch(GrammarException e) {  System.out.println("crap grammar");    } 	
		catch(Exception e) {  e.printStackTrace(System.out);    } 	
		parent.showInitialText();
	} //end of parseInputFile
	
	public void nextGrammar(int shift) {
		parent.suspend();
		System.out.println("moving to next grammar");
		try {
			System.out.println("current grammar set: " + currentGrammarSet + ", and number of grammar sets: " + grammarSizes.size());
			if (currentGrammarSet == grammarSizes.size()) {
				System.out.println("\n\n\n\n\n\nwe're all done dave, hooray!\n\n\n\n\n\n\n\n");
				parent.fireStudyPalEvent(0);
			}
			else {
//			RuleGrammar tempGram;
			if (currentGrammar == -1) {
				
				int tempGramSize = Integer.parseInt(String.valueOf(grammarSizes.get(currentGrammarSet)));
				System.out.println("next grammar: this sentence is of size: " + tempGramSize);
				for (int i=0;i<tempGramSize; i++) {
					System.out.println("********* enabling grammar number " + String.valueOf(currentGrammar + 1));
					activeGrammar = rec.getRuleGrammar(String.valueOf(currentGrammar+1));
					activeGrammar.setEnabled(true);
					currentGrammar += 1;					
				}

			}
			else {
				//disable previous grammars
				int tempGramSize = Integer.parseInt(String.valueOf(grammarSizes.get(currentGrammarSet-1)));
				for (int i=0;i<tempGramSize; i++) {
					System.out.println("********* disabling grammar number " + String.valueOf(currentGrammar - i +1));
					activeGrammar = rec.getRuleGrammar(String.valueOf(currentGrammar - i+1));
					activeGrammar.setEnabled(false);
				}
				//enable current grammars
				tempGramSize = Integer.parseInt(String.valueOf(grammarSizes.get(currentGrammarSet)));
				System.out.println("next grammar: this sentence is of size: " + tempGramSize);
				for (int i=0;i<tempGramSize; i++) {
					System.out.println("********* enabling grammar number " + String.valueOf(currentGrammar+1));
					activeGrammar = rec.getRuleGrammar(String.valueOf(currentGrammar+1));
					activeGrammar.setEnabled(true);
					currentGrammar += 1;					
				}
			}
			
			currentGrammarSet += 1;
			}
//			System.out.println("active grammar is number: " + currentGrammar + ", which has the following phrases: " + tempGram.getRule("phrase").toString());
			rec.commitChanges();
			rec.waitEngineState(rec.LISTENING);
			parent.resume();
		} catch (Exception e) {	e.printStackTrace(System.out); }
	} //end of nextGrammar
/*
	void startTimer() {
		//timer = new java.util.Timer();
		TimerTask task2 = new TimerTask() {
			public void run() {
				System.out.println( "///////////////////// i'm in the task ");
				if (!hasStoppedReading) {
					System.out.println( "///////////////////// you have stopped reading! ");				
					timer.cancel();					
					hasStoppedReading = true;
					parent.fireStudyPalEvent(2);	
				}
			}
		}; //end timer task			
		try { timer.schedule(task2, 5000);		}
		catch (IllegalStateException le) { System.out.println("oops, the timer has already been scheduled or canceled");}			
	}
*/	
    public void resultRejected(ResultEvent e) {		
		//System.out.println("rejected");
		resetReadingTimeCounter();		
		
        Result r = (Result)(e.getSource());
		movementByUpdater = 0;
    }
    public void resultCreated(ResultEvent e) {
		//System.out.println("result created");	
		resetReadingTimeCounter();
		
        Result r = (Result)(e.getSource());
    }
    public void resultUpdated(ResultEvent e) {
        Result r = (Result)(e.getSource());
        //System.out.println("Result Updated... "+r);
		resetReadingTimeCounter();
		ResultToken [] tokens = r.getBestTokens();
		
		if(tokens != null && tokens.length > 0) {
			
			//if true, we've received a finalized utterance (we've heard silence)
			if (r.getResultState() != Result.UNFINALIZED) {
				String tags[] = null;
				tags = ((FinalRuleResult)r).getTags();
				String tempString;
				tempString = tokens[0].getWrittenText();
				
				//how to move forward
				if (currentWordInParagraph +1 > theWholeParagraph.size()) {
					System.out.println("hooray, we're done!");
					parent.fireStudyPalEvent(0);					
				}
				
				String tempString2 = (String)theWholeParagraph.get(currentWordInParagraph);
				tempString = cleanString(tempString);
				tempString2 = cleanString(tempString2);				

				//System.out.println("finalized: last word you said: <" + tempString + ">");
				//System.out.println("finalized: next word i expect: <" + tempString2 + ">");		
				if (tempString.compareTo(tempString2) == 0) {
					//System.out.println("finalized: we can move ahead one!");
					movementByUpdater += 1;
					parent.moveReadMarker(1);
					currentWordInSentence += 1;
					currentWordInParagraph += 1;	
				}
				//end of how to move forward
				
				//System.out.println("this is last update, check if end of sentence");
				//System.out.println ("tags: ");
				//for (int i=0; i< tags.length; i++) {
					//System.out.println(tags[i]);
				//}						

				int tempGramSize = Integer.parseInt(String.valueOf(grammarSizes.get(currentGrammarSet-1)));
				//System.out.println("finalized: there are " + tempGramSize + " words in this sentence, i think");

//				if (tags != null && tags.length > 1) {
				if (tags != null && (currentWordInSentence == tempGramSize || tags.length > 1)) {
					//System.out.println("you said the last word, which is word number " + tags[0] + ", and the last word said was " + currentWordInSentence);
					int diff = Integer.parseInt(tags[0]) - currentWordInSentence;
					//System.out.println("difference of " + diff);
					if (diff < 2) {
						currentWordInSentence = 0;
						nextGrammar(1);
					}
				}
			}
			else {
				int tempCounter = movementByUpdater;

				while (tempCounter < tokens.length) {
					String tempString;
					tempString = tokens[tempCounter].getWrittenText();
					tempCounter += 1;					
					//how to move forward
					if (currentWordInParagraph +1 > theWholeParagraph.size()) {
						System.out.println("hooray, we're done!");
						parent.fireStudyPalEvent(0);						
					}					
					String tempString2 = (String)theWholeParagraph.get(currentWordInParagraph);
					
					tempString = cleanString(tempString);
					tempString2 = cleanString(tempString2);									
					
					//System.out.println("update: last word you said: <" + tempString + ">");
					//System.out.println("update: next word i expect: <" + tempString2 + ">");		
					if (tempString.compareTo(tempString2) == 0) {
						//System.out.println("update: we can move ahead one!");
						movementByUpdater += 1;
						parent.moveReadMarker(1);
						currentWordInSentence += 1;
						currentWordInParagraph += 1;	
					}
					//end of how to move forward
					
					//time to go to next grammar?  just a test dave
					int tempGramSize = Integer.parseInt(String.valueOf(grammarSizes.get(currentGrammarSet-1)));					
					//System.out.println("update: there are " + tempGramSize + " words in this sentence, i think, and the current word in sentence is " + currentWordInSentence);					
					if (currentWordInSentence == tempGramSize) {
						currentWordInSentence = 0;
						nextGrammar(1);
					}
						
				} //end of while	

			} //end of else
		} //end of if there are any tokens
	} //end resultupdated
    
	String cleanString(String str) {
		str.trim();
		str = str.replace(",", "");
		str = str.replace(";", "");
		str = str.toLowerCase();
		return str;
	} //end cleanString
	
	public void moveAheadByOne() {
		parent.fireStudyPalEvent(1);
		movementByUpdater += 1;
		parent.moveReadMarker(1);
		currentWordInSentence += 1;
		currentWordInParagraph += 1;	

		int tempGramSize = Integer.parseInt(String.valueOf(grammarSizes.get(currentGrammarSet-1)));
		System.out.println("skip word: there are " + tempGramSize + " words in this sentence, i think, and the current word in sentence is " + currentWordInSentence);

		if (currentWordInSentence >= tempGramSize ) {
//			System.out.println("skip word: going to next sentence");
			currentWordInSentence = 0;
			nextGrammar(1);		
		}		
		movementByUpdater = 0;		
	} //end moveAheadByOne

	void resetReadingTimeCounter() {
		hasStoppedReading = false;
		secondsElapsed = 0;
	}
	
    public  void resultAccepted(ResultEvent e) {
		//System.out.println("Result Accepted");
		resetReadingTimeCounter();
		
        final FinalResult r = (FinalResult)(e.getSource());		
		movementByUpdater = 0;
		
        Runnable lt = new Runnable() {
            public void run() {
                try {
      //              System.out.print("Result Accepted: "+r);
                    ResultToken tokens[] = null;
					String tags[] = null;

                    if(r.getGrammar() instanceof RuleGrammar) {
                        tokens = ((FinalRuleResult)r).getAlternativeTokens(0);
						tags = ((FinalRuleResult)r).getTags();				
						
	//					System.out.println("\n $$$$$$$$$$ tag: " + tags[0] + " sentence: " + currentWordInSentence);
						int tagNumber = Integer.parseInt(tags[0]);
		
						//must ensure we're not skipping
						if (tagNumber > 0 && tokens.length == tagNumber - currentWordInSentence) { 
							//currentWordInSentence = tagNumber;
							
							//now, do we move to the next grammar?
							if (tags.length > 1) {
								System.out.println("second tag is " + tags[1]);
							}	
						}
						
						String rule = ((FinalRuleResult)r).getRuleName(0);
						String word = "";						
						for (int i = 0; i<tokens.length; i++) {
							word += tokens[i].getWrittenText() + " ";							
						}
						word = word.trim();
						//System.out.println ("you said: " + word);
                    } 
                                        
                } catch(Exception e1) {
                    e1.printStackTrace(System.out);
                } catch(ResultStateError er) {
                    er.printStackTrace(System.out);
                }
            }
        };
        (new Thread(lt)).start();
        
    }
}