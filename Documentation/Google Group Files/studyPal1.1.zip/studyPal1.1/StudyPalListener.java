public interface StudyPalListener {
	public void documentCompleted(StudyPalEvent e);
	public void wordSkipped(StudyPalEvent e);
	public void readingPaused(StudyPalEvent e);
} //end interface
