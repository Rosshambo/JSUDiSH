import java.util.EventObject;
public class StudyPalEvent extends EventObject {
    
	public StudyPalEvent( Object source) {
        super(source);
    }
}