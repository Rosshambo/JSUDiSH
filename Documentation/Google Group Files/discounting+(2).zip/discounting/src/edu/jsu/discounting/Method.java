package edu.jsu.discounting;

import java.util.List;
import java.util.ArrayList;

public class Method {
	public enum Type {DOUBLE_LIMIT, DECREASING_ADJUSTMENT, MULTIPLE_CHOICE};
	protected Type type;
    protected Reward minReward;
    protected Reward maxReward;
	protected Time maxTime;
	protected Time responseDelay;
    protected List<Scenario> scenarios;
    protected Option indifferencePoint;
	
	public Method(Type type) {
		this.type = type;
		minReward = null;
		maxReward = null;
		maxTime = null;
		responseDelay = null;
        scenarios = new ArrayList<Scenario>();
        indifferencePoint = null;
	}
	
	public Type getType() { return type; }
	public void setType(Type t) { type = t; }
	public Reward getMinReward() { return minReward; }
	public void setMinReward(Reward r) { minReward = r; }    
	public Reward getMaxReward() { return maxReward; }
	public void setMaxReward(Reward r) { maxReward = r; }
	public Time getMaxTime() { return maxTime; }
	public void setMaxTime(Time t) { maxTime = t; }
	public Time getResponseDelay() { return responseDelay; }
	public void setResponseDelay(Time t) { responseDelay = t; }
    public int getNumScenarios() { return scenarios.size(); }
    public List<Scenario> getScenarios() { return scenarios; }
    public void addScenario(Scenario s) { scenarios.add(s); }
    public Scenario getScenario(int i) throws ArrayIndexOutOfBoundsException { return scenarios.get(i); }
    public Option getIndifferencePoint() { return indifferencePoint; }
    public void setIndifferencePoint(Option ip) { indifferencePoint = ip; }
    
    public String toString() {
        String s = "";
        s += "Type: " + type + "\n";
        s += "Min Reward: " + minReward + "\n";
        s += "Max Reward: " + maxReward + "\n";
        s += "Max Time: " + maxTime + "\n";
        s += "Response Delay: " + responseDelay + "\n";
        s += "Indifference Point: " + indifferencePoint + "\n";
        if(scenarios.size() > 0) {
            s += "Num Scenarios: " + scenarios.size() + "\n";
            for(Scenario scen : scenarios) {
                s += "=========================\n";
                s += scen;
                s += "=========================\n";
            }
        }
        return s;
    }
    
    public static int toCode(Type type) {
        if(type == Type.DOUBLE_LIMIT) return 1;
        else if(type == Type.DECREASING_ADJUSTMENT) return 2;
        else return 3;
    }
}