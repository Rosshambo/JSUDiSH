package edu.jsu.discounting;

import java.text.DecimalFormat;

public class Time {
	public enum Type { SECONDS, MINUTES, HOURS, DAYS, WEEKS, MONTHS, YEARS };
    private static final int NUM_DECIMAL_PLACES = 4;
	private double value;
	private Type type;

    private double round(double d, int numPlaces) {
        int scale = (int)Math.pow(10, numPlaces);
        int id = (int)(d * scale);
        return (double)id / (double)scale;
    }
	
	public Time() {
		value = 0;
		type = Type.SECONDS;
	}
	
	public Time(double v, Type t) {
		value = round(v, NUM_DECIMAL_PLACES);
		type = t;
	}
	
	public double getValue() { return value; }
	public void setValue(double v) { value = round(v, NUM_DECIMAL_PLACES); }
	public Type getType() { return type; }
	public void setType(Type t) { type = t; }

    public boolean equals(Time t) {
        return (value == t.value && type == t.type);
    }
	
	public String toString() {
		if(value > 0) {
       		DecimalFormat format = new DecimalFormat("0.###");
            format.setMaximumFractionDigits(3);
			String s = format.format(value);
			s += " ";
			switch(type) {
				case SECONDS: s += "second"; break;
				case MINUTES: s += "minute"; break;
				case HOURS: s += "hour"; break;
				case DAYS: s += "day"; break;
				case WEEKS: s += "week"; break;
				case MONTHS: s += "month"; break;
				case YEARS: s += "year"; break;
			}
            if(value != 1) {
                s += "s";
            }
			return s;
		}
		else {
			return "now";
		}
	}
	
	public long convertToMillis() {
		long scale = 0;
		switch(type) {
			case SECONDS: scale = 1000; break;
			case MINUTES: scale = 60000; break;
			case HOURS: scale = 3600000; break;
			case DAYS: scale = 86400000; break;
			case WEEKS: scale = 604800000; break;
			case MONTHS: scale = 999999999; break;
			case YEARS: scale = 999999999; break;
		}
		return (long)(value * scale);
	}
    
    public float convertToSeconds() {
		long scale = 0;
		switch(type) {
			case SECONDS: scale = 1; break;
			case MINUTES: scale = 60; break;
			case HOURS: scale = 3600; break;
			case DAYS: scale = 86400; break;
			case WEEKS: scale = 604800; break;
			case MONTHS: scale = 2419200; break;
			case YEARS: scale = 29030400; break;
		}
		return (float)(value * scale);        
    }
    
    public static int toCode(Type type) {
        if(type == Type.SECONDS) return 1;
        else if(type == Type.MINUTES) return 2;
        else if(type == Type.HOURS) return 3;
        else if(type == Type.DAYS) return 4;
        else if(type == Type.WEEKS) return 5;
        else if(type == Type.MONTHS) return 6;
        else return 7;
    }
}