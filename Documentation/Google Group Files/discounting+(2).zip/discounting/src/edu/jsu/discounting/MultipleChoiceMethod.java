package edu.jsu.discounting;


public class MultipleChoiceMethod extends Method {
	private String distribution;
	
	public MultipleChoiceMethod() {
		super(Method.Type.MULTIPLE_CHOICE);
		distribution = "";
	}
	
	public String getDistribution() { return distribution; }
	public void setDistribution(String d) { distribution = d; }
    
    public String toString() {
        String s = super.toString();
        s += "Distribution: " + distribution + "\n";  
        return s;
    }
}