package edu.jsu.discounting;

import java.util.List;
import java.util.ArrayList;


public class Experiment {
	private List<Investigator> personnel;
	private String title;
	private int number;
	private String instructions;
	private List<Method> methods;
    private ParticipantInformation participantInformation;
	private String conclusion;

	public Experiment() {
		personnel = new ArrayList<Investigator>();
		title = null;
		number = 1;
		instructions = null;
		methods = new ArrayList<Method>();
        participantInformation = null;
		conclusion = null;
	}	
	
	public List<Investigator> getPersonnel() { return personnel; }
	public void addPersonnel(Investigator i) { personnel.add(i); }
	public int getNumPersonnel() { return personnel.size(); }
	public Investigator getPersonnel(int i) throws ArrayIndexOutOfBoundsException { return personnel.get(i); }	
	public String getTitle() { return title; }
	public void setTitle(String t) { title = t; }
	public int getNumber() { return number; }
	public void setNumber(int n) { number = n; }
	public String getInstructions() { return instructions; }
	public void setInstructions(String instruct) { instructions = instruct; }
	public List<Method> getMethods() { return methods; }
	public void addMethod(Method m) { methods.add(m); }
	public int getNumMethods() { return methods.size(); }
	public Method getMethod(int i) throws ArrayIndexOutOfBoundsException { return methods.get(i); }
    public ParticipantInformation getParticipantInformation() { return participantInformation; }
    public void setParticipantInformation(ParticipantInformation pi) { participantInformation = pi; }
	public String getConclusion() { return conclusion; }
	public void setConclusion(String c) { conclusion = c; }
	
	
	public String toString() {
        String s = "";
		s += "Personnel: \n";
		for(int i = 0; i < personnel.size(); i++) {
			s += "   " + personnel.get(i) + "\n";
		}
		s += "Title: " + title + "\n";
		s += "Number: " + number + "\n";
		s += "Instructions: " + instructions + "\n";
		s += "Number of Methods: " + methods.size() + "\n";
		for(int i = 0; i < methods.size(); i++) {
            s += "+++++++++++++++++++++++++\n";
            s += methods.get(i).toString();
            s += "+++++++++++++++++++++++++\n";
 		}
        s += "Participant Information:\n";
        s += participantInformation + "\n";
		s += conclusion + "\n";
        return s;
	}
}
