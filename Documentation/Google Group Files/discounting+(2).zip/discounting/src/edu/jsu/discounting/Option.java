package edu.jsu.discounting;

public class Option {
	private Reward reward;
	private Time time;
	
    public Option() {
        reward = new Reward();
        time = new Time();
    }
    
	public Option(Reward r, Time t) {
		reward = r;
		time = t;
	}
	
	public Reward getReward() { return reward; }
	public void setReward(Reward r) {
		reward = r;
	}
	public Time getTime() { return time; }
	public void setTime(Time t) {
		time = t;
	}
    
    public boolean equals(Option o) {
        return (reward.equals(o.reward) && time.equals(o.time));
    }
    
	public String toString() {
        String s = reward.toString() + " ";
        if(time.getValue() > 0) {
            s += "in ";
        }
        s += time.toString();
		return s;
	}    
} 