package edu.jsu.discounting;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;


import net.miginfocom.swing.MigLayout;


public class DecreasingAdjustmentMethodUI extends MethodUI implements ActionListener {
	private JButton confirmButton;
	private double adjustment;
	private int numTrials;
	private int maxNumTrials;
    private Scenario currentScenario;
    private ScenarioUI currentScenarioUI;
    private JPanel scenarioPanel;
		
	public DecreasingAdjustmentMethodUI(DecreasingAdjustmentMethod method) {
		super(method);
		adjustment = 0;
		numTrials = 0;
		maxNumTrials = method.getNumTrials();
		adjustment = (method.getMaxReward().getValue() - method.getMinReward().getValue()) / 2.0;
        
        currentScenario = new Scenario();
        currentScenario.addOption(new Option(new Reward(method.getMinReward().getValue() + adjustment, method.getMinReward().getType()), new Time()));
        currentScenario.addOption(new Option(method.getMaxReward(), method.getMaxTime()));
        currentScenario.setResponseDelay(method.getResponseDelay());
        currentScenarioUI = new ScenarioUI(currentScenario);
        
        scenarioPanel = new JPanel();
        scenarioPanel.setLayout(new MigLayout("fill"));
        this.add(scenarioPanel, "center,grow,wrap");
        scenarioPanel.add(currentScenarioUI, "center,grow,wrap");
        
		confirmButton = new JButton("Confirm Choice");
		confirmButton.addActionListener(this);
		this.add(confirmButton, "center,span");	
    }

    public void begin() {
        currentScenarioUI.begin();
    }
		    
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == confirmButton) {
            confirmButton.setEnabled(false);
            boolean optionSelected = currentScenarioUI.isOptionSelected();
			if(!optionSelected) {
				JOptionPane.showMessageDialog(this.getTopLevelAncestor(), "You must select an option.", "Incomplete Information", JOptionPane.ERROR_MESSAGE);
			}
			else {
                OptionUI low = currentScenarioUI.getOptionUI(0);
                OptionUI high = currentScenarioUI.getOptionUI(1);
                double lower = low.getOption().getReward().getValue();
				double upper = high.getOption().getReward().getValue();
				double value;
				if(low.isSelected()) {
                    currentScenario.setChosenOption(low.getOption());
					value = lower - adjustment / 2.0;
					if(value < method.getMinReward().getValue()) { value = method.getMinReward().getValue(); }
				}
				else {
                    currentScenario.setChosenOption(high.getOption());
					value = lower + adjustment / 2.0;
					if(value > method.getMaxReward().getValue()) { value = method.getMaxReward().getValue(); }
				}
				adjustment /= 2.0;
				numTrials++;

                // Add the scenario to our bundle.
                method.addScenario(currentScenario);

                // Are we finished?
				if(numTrials >= maxNumTrials) {
					method.setIndifferencePoint(low.getOption());
					((ExperimentUI)this.getParent()).next();
				}
				else {
                    currentScenario = new Scenario();
                    currentScenario.addOption(new Option(new Reward(value, method.getMinReward().getType()), new Time()));
                    currentScenario.addOption(new Option(method.getMaxReward(), method.getMaxTime()));
                    currentScenario.setResponseDelay(method.getResponseDelay());
                    scenarioPanel.removeAll();
                    currentScenarioUI = new ScenarioUI(currentScenario);
                    scenarioPanel.add(currentScenarioUI, "center,grow,wrap");
                    this.validate();
                    begin();
				}
			}
            confirmButton.setEnabled(true);
		}
	}
	
	
	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Method m;
		m = new DecreasingAdjustmentMethod();
		m.setMinReward(new Reward(0.5, "junk"));
		m.setMaxReward(new Reward(20.0, "junk"));
		m.setMaxTime(new Time(30, Time.Type.SECONDS));
		m.setResponseDelay(new Time(1, Time.Type.SECONDS));
		((DecreasingAdjustmentMethod)m).setNumTrials(5);
		MethodUI mp = new DecreasingAdjustmentMethodUI((DecreasingAdjustmentMethod)m);
		window.add(mp);
		window.pack();
		window.setVisible(true);
		mp.begin();
	}
}










