package edu.jsu.discounting;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;


public class DatabaseConnector {
	public static final String DB_NAME = "discounting";
	public static final String DB_USER = "root";
	public static final String DB_PASS = "";
    
    private static class DatabaseField {
        public String name;
        public String value;
        public DatabaseField() {
            name = null;
            value = null;
        }
        public DatabaseField(String n, String v) {
            name = n;
            value = v;
        }
    }
    
    private static String sqlstr(String s) {
        return "'" + s + "'";
    }
    
    private static int insertIfNeeded(Connection dbConn, String dbTable, List<DatabaseField> search, List<DatabaseField> insert) throws SQLException {
        dbTable = "discounting.`" + dbTable + "`";
        Statement stmt = dbConn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
        String searchQuery = "SELECT id FROM " + dbTable + " WHERE ";
        int count = search.size();
        for(DatabaseField f : search) {
            searchQuery += f.name + "=" + f.value;
            if(count > 1) {
                searchQuery += " AND ";
            }
            count--;
        }
        searchQuery += ";";
        
        ResultSet rs = stmt.executeQuery(searchQuery);
        boolean alreadyExists = rs.next();
        if(!alreadyExists) {
            String insertQuery = "INSERT INTO " + dbTable + " (";
            count = insert.size();
            for(DatabaseField f : insert) {
                insertQuery += f.name;
                if(count > 1) {
                    insertQuery += ", ";
                }
                count--;
            }
            insertQuery += ") VALUES (";
            count = insert.size();
            for(DatabaseField f : insert) {
                insertQuery += f.value;
                if(count > 1) {
                    insertQuery += ", ";
                }
                count--;
            }
            insertQuery += ");";
            
            stmt.executeUpdate(insertQuery);
            rs = stmt.executeQuery(searchQuery);            
            rs.next();
        }
        
        return rs.getInt("id");
    }
    
	public static void insert(Experiment experiment) {
    	// Database stuff...
		Connection dbConnection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			dbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + DB_NAME, DB_USER, DB_PASS);
			
			if(!dbConnection.isClosed()) {
				System.out.println("Successfully connected to MySQL server using TCP/IP...");
				
                // Add the experiment...
                List<DatabaseField> dbSearch = new ArrayList<DatabaseField>();
                dbSearch.add(new DatabaseField("title",sqlstr(experiment.getTitle())));
                dbSearch.add(new DatabaseField("number", String.valueOf(experiment.getNumber())));
                List<DatabaseField> dbInsert = new ArrayList<DatabaseField>(dbSearch);
                dbInsert.add(new DatabaseField("instructions", sqlstr(experiment.getInstructions())));
                int experimentID = insertIfNeeded(dbConnection, "experiment", dbSearch, dbInsert);
                
                // Add the investigators... 
                List<Investigator> personnel = experiment.getPersonnel();
                for(Investigator inv : personnel) {
                    dbSearch = new ArrayList<DatabaseField>();
                    dbSearch.add(new DatabaseField("fname", sqlstr(inv.getFirstName())));
                    dbSearch.add(new DatabaseField("lname", sqlstr(inv.getLastName())));
                    dbSearch.add(new DatabaseField("department", sqlstr(inv.getDepartment())));
                    int id = insertIfNeeded(dbConnection, "investigator", dbSearch, dbSearch);
                    
                    // Link the experiment and investigator...
                    dbSearch = new ArrayList<DatabaseField>();
                    dbSearch.add(new DatabaseField("eid", String.valueOf(experimentID)));
                    dbSearch.add(new DatabaseField("iid", String.valueOf(id)));
                    insertIfNeeded(dbConnection, "investigator-experiment", dbSearch, dbSearch);
                }
                
                // Add the participant...
                ParticipantInformation participant = experiment.getParticipantInformation();
                dbSearch = new ArrayList<DatabaseField>();
                dbSearch.add(new DatabaseField("id_number", sqlstr(participant.getId())));
                dbInsert = new ArrayList<DatabaseField>(dbSearch);
                dbInsert.add(new DatabaseField("fname", sqlstr(participant.getFirstName())));
                dbInsert.add(new DatabaseField("lname", sqlstr(participant.getId())));
                dbInsert.add(new DatabaseField("age", String.valueOf(participant.getAge())));
                dbInsert.add(new DatabaseField("race", String.valueOf(ParticipantInformation.toCode(participant.getRace()))));
                dbInsert.add(new DatabaseField("gender", String.valueOf(ParticipantInformation.toCode(participant.getGender()))));
                int participantID = insertIfNeeded(dbConnection, "participant", dbSearch, dbInsert);
                
                // Link the experiment and the participant...
                dbSearch = new ArrayList<DatabaseField>();
                dbSearch.add(new DatabaseField("eid", String.valueOf(experimentID)));
                dbSearch.add(new DatabaseField("pid", String.valueOf(participantID)));
                insertIfNeeded(dbConnection, "participant-experiment", dbSearch, dbSearch);
             
                // Add the methods...
                List<Method> methods = experiment.getMethods();
                for(Method m : methods) {
                    // Insert the method...
                    dbSearch = new ArrayList<DatabaseField>();
                    dbSearch.add(new DatabaseField("type", String.valueOf(Method.toCode(m.getType()))));
                    dbSearch.add(new DatabaseField("min_reward", String.valueOf(m.getMinReward().getValue())));
                    dbSearch.add(new DatabaseField("max_reward", String.valueOf(m.getMaxReward().getValue())));
                    dbSearch.add(new DatabaseField("response_delay", String.valueOf(m.getResponseDelay().convertToSeconds())));
                    dbSearch.add(new DatabaseField("max_time_value", String.valueOf(m.getMaxTime().getValue())));
                    dbSearch.add(new DatabaseField("max_time_type", String.valueOf(Time.toCode(m.getMaxTime().getType()))));
                    dbSearch.add(new DatabaseField("reward_type", sqlstr(m.getMinReward().getType())));
                    dbSearch.add(new DatabaseField("indifference_value", String.valueOf(m.getIndifferencePoint().getReward().getValue())));
                    int mid = insertIfNeeded(dbConnection, "method", dbSearch, dbSearch);
                    
                    // Link the method up with the experiment...
                    dbSearch = new ArrayList<DatabaseField>();
                    dbSearch.add(new DatabaseField("eid", String.valueOf(experimentID)));
                    dbSearch.add(new DatabaseField("mid", String.valueOf(mid)));
                    insertIfNeeded(dbConnection, "experiment-method", dbSearch, dbSearch);
                    
                    List<Scenario> scenarios = m.getScenarios();
                    for(Scenario s : scenarios) {
                        int choiceID = -1;
                        // Insert the options...
                        List<Integer> optionID = new ArrayList<Integer>();
                        List<Option> options = s.getOptions();
                        for(Option o : options) {
                            // Insert the option...
                            dbSearch = new ArrayList<DatabaseField>();
                            dbSearch.add(new DatabaseField("reward_value", String.valueOf(o.getReward().getValue())));
                            dbSearch.add(new DatabaseField("reward_type", sqlstr(o.getReward().getType())));
                            dbSearch.add(new DatabaseField("time_value", String.valueOf(o.getTime().getValue())));
                            dbSearch.add(new DatabaseField("time_type", String.valueOf(Time.toCode(o.getTime().getType()))));
                            int oid = insertIfNeeded(dbConnection, "option", dbSearch, dbSearch);
                            if(o.equals(s.getChosenOption())) {
                                choiceID = oid;
                            }
                            optionID.add(oid);
                        }
                        assert(choiceID >= 0);
                        
                        // Insert the scenario...
                        dbSearch = new ArrayList<DatabaseField>();
                        dbSearch.add(new DatabaseField("choice", String.valueOf(choiceID)));
                        int sid = insertIfNeeded(dbConnection, "scenario", dbSearch, dbSearch);
                        
                        // Link the options up with the scenario...
                        for(Integer i : optionID) {
                            dbSearch = new ArrayList<DatabaseField>();
                            dbSearch.add(new DatabaseField("sid", String.valueOf(sid)));
                            dbSearch.add(new DatabaseField("oid", String.valueOf(i)));
                            insertIfNeeded(dbConnection, "scenario-option", dbSearch, dbSearch);
                        }
                        
                        // Link the scenario up with the method...
                        dbSearch = new ArrayList<DatabaseField>();
                        dbSearch.add(new DatabaseField("mid", String.valueOf(mid)));
                        dbSearch.add(new DatabaseField("sid", String.valueOf(sid)));
                        insertIfNeeded(dbConnection, "method-scenario", dbSearch, dbSearch);
                    }
                                        
                    // Update the number of trials (if applicable)...
                    if(m.getType() == Method.Type.DECREASING_ADJUSTMENT) {
                        int numTrials = ((DecreasingAdjustmentMethod)m).getNumTrials();
                        Statement stmt = dbConnection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
                        String updateQuery = "UPDATE discounting.`method` SET num_trials='" + numTrials + "' WHERE id=" + mid +";";
                        stmt.executeUpdate(updateQuery);                                                
                    }
                    // Update the distribution (if applicable)...
                    else if(m.getType() == Method.Type.MULTIPLE_CHOICE) {
                        String distribution = ((MultipleChoiceMethod)m).getDistribution();
                        Statement stmt = dbConnection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
                        String updateQuery = "UPDATE discounting.`method` SET distribution='" + distribution + "' WHERE id=" + mid +";";
                        stmt.executeUpdate(updateQuery);                        
                    }
                }
			}
		}	
		catch(Exception e) {
			System.err.println("Exception: " + e.getMessage());
            e.printStackTrace();
		} 
		finally {
			try {
				if(dbConnection != null) {
					dbConnection.close();
				}
			} 
			catch(SQLException e) {}
		}        
	}
    
    
    public static void main(String[] args) {
        Experiment exp = new Experiment();
        for(int i = 0; i < 3; i++) {
            Investigator n = new Investigator();
            n.setFirstName("bob" + String.valueOf(i));
            n.setLastName("smith" + String.valueOf(i));
            n.setDepartment("dept" + String.valueOf(i));
            exp.addPersonnel(n);
        }
        exp.setTitle("some title goes here");
        exp.setNumber(1337);
        exp.setInstructions("instructions go here");
        ParticipantInformation pi = new ParticipantInformation();
        pi.setFirstName("John");
        pi.setLastName("Smith");
        pi.setAge(25);
        pi.setId("012345432");
        pi.setRace(ParticipantInformation.Race.BLACK);
        pi.setGender(ParticipantInformation.Gender.FEMALE);
        exp.setParticipantInformation(pi);
        
        
        insert(exp);
    }
}
   