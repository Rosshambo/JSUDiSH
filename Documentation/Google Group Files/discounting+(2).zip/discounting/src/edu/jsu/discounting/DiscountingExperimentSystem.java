package edu.jsu.discounting;

import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.CmdLineException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import org.xml.sax.XMLReader;
import javax.swing.JPasswordField;
import javax.swing.JDialog;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Validator;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.xml.sax.SAXException;

import net.miginfocom.swing.MigLayout;


public class DiscountingExperimentSystem extends JFrame implements ActionListener {
	private String adminPassword;
	private JMenuBar menuBar;
	private JMenu adminMenu;
	private JMenuItem loadExperimentMenuItem;
	private Experiment currentExperiment;
	private ExperimentUI experimentUI;
	private JPanel mainContentPanel;    

	public DiscountingExperimentSystem(String adminPwd) {
		adminPassword = adminPwd;
		
		setTitle("Discounting in Study Habits");
		menuBar = new JMenuBar();
		adminMenu = new JMenu("Administration");
		adminMenu.setMnemonic(KeyEvent.VK_A);
		adminMenu.getAccessibleContext().setAccessibleDescription("Administrative functions like loading and stopping experiments");
		menuBar.add(adminMenu);
		
		loadExperimentMenuItem = new JMenuItem("Load Experiment", KeyEvent.VK_L);
		loadExperimentMenuItem.addActionListener(this);
		loadExperimentMenuItem.getAccessibleContext().setAccessibleDescription("Loads an experiment from an XML file");
		adminMenu.add(loadExperimentMenuItem);

		this.setJMenuBar(menuBar);
		
		currentExperiment = null;
		mainContentPanel = new JPanel();
		mainContentPanel.setPreferredSize(new Dimension(200, 200));
		this.add(mainContentPanel);        
	}

	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == loadExperimentMenuItem) {
            final JPasswordField jpf = new JPasswordField();
            JOptionPane jop = new JOptionPane(jpf, JOptionPane.QUESTION_MESSAGE, JOptionPane.OK_CANCEL_OPTION);
            JDialog dialog = jop.createDialog("Enter Password");
            dialog.addComponentListener(new ComponentAdapter(){
                                                @Override
                                                public void componentShown(ComponentEvent e){
                                                    jpf.requestFocusInWindow();
                                                }
                                            });
            dialog.setVisible(true);
            int result = (Integer)jop.getValue();
            dialog.dispose();
            char[] password = null;
            if(result == JOptionPane.OK_OPTION){
                password = jpf.getPassword();
            }
            
			if(password != null) {
				if(adminPassword.equals(new String(password))) {
					JFileChooser chooser = new JFileChooser();
					FileNameExtensionFilter filter = new FileNameExtensionFilter("XML Experiment Files", "xml");
					chooser.setFileFilter(filter);
					int returnVal = chooser.showOpenDialog(this);
					if(returnVal == JFileChooser.APPROVE_OPTION) {
						try {
							// Validate the XML file.
							SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
							File schemaLocation = new File("experiment.xsd");
							Schema schema = factory.newSchema(schemaLocation);
							Validator validator = schema.newValidator();
							Source source = new StreamSource(chooser.getSelectedFile());
							validator.validate(source);
							
							// If it validates, then load the experiment.
							XMLReader parser = org.xml.sax.helpers.XMLReaderFactory.createXMLReader();
							SaxExperimentHandler contentHandler = new SaxExperimentHandler();
							parser.setContentHandler(contentHandler);
							parser.parse(chooser.getSelectedFile().toURI().toString());
							currentExperiment = contentHandler.getExperiment();
							
//							System.out.println(currentExperiment);
							
							experimentUI = new ExperimentUI(currentExperiment);
							mainContentPanel.add(experimentUI);
							mainContentPanel.validate();
						}
						catch (SAXException ex) {
							// If the file doesn't validate against the schema...
							JOptionPane.showMessageDialog(this, ex.getMessage(), "Error in Experiment XML", JOptionPane.ERROR_MESSAGE);
						}  
						catch(FileNotFoundException ex) {
							// If the file doesn't exist...
							JOptionPane.showMessageDialog(this, "The file could not be found.", "File Not Found", JOptionPane.ERROR_MESSAGE);
						}
						catch(IOException ex) {
							// If other bad stuff happens...
							JOptionPane.showMessageDialog(this, "An I/O error has occurred.", "I/O Error", JOptionPane.ERROR_MESSAGE);
						}
					}
				}					
				else {
					JOptionPane.showMessageDialog(this, "The password was invalid.", "Invalid Password!", JOptionPane.ERROR_MESSAGE);
				}
			}
		}
	}

    public void reset() {
        mainContentPanel.removeAll();
        mainContentPanel.validate();
        repaint();
    }

	public static void main(String args[]) {
	
		// Command-line argments...
		CommandLineOptions clo = new CommandLineOptions();
		CmdLineParser parser = new CmdLineParser(clo);
		String pwd = "skinner";
		try {
			parser.parseArgument(args);
            if(clo.password != null) {
                pwd = clo.password;
            }
		}
		catch (CmdLineException e) {
			// handling of wrong arguments
			System.err.println(e.getMessage());
			parser.printUsage(System.err);
		}
		
		// Window...
		DiscountingExperimentSystem window = new DiscountingExperimentSystem(pwd);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        window.setExtendedState(JFrame.MAXIMIZED_BOTH | window.getExtendedState());

//		window.setResizable(false);
		window.setVisible(true);
	}
}