package edu.jsu.discounting;

import org.kohsuke.args4j.Option;

public class CommandLineOptions {
	@Option(name="-password", usage="The administrative password")
	public String password;
}
   