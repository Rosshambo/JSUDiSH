package edu.jsu.discounting;

import java.util.List;
import java.util.ArrayList;

public class Scenario {
	private List<Option> options;
    private Option chosenOption;
    private Time responseDelay;
	
	public Scenario() {
		options = new ArrayList<Option>();
        chosenOption = null;
        responseDelay = null;
	}
	
    public int getNumOptions() { return options.size(); }
	public List<Option> getOptions() { return options; }
	public void addOption(Option o) { options.add(o); }
    public Option getOption(int i) throws ArrayIndexOutOfBoundsException { return options.get(i); }
    public Option getChosenOption() { return chosenOption; }
    public void setChosenOption(Option o) { chosenOption = o; }
    public Time getResponseDelay() { return responseDelay; }
    public void setResponseDelay(Time rd) { responseDelay = rd; }
    
    public String toString() {
        String s = "";
        s += "Response Delay: " + responseDelay + "\n";
        s += "Chosen Option: " + chosenOption + "\n";
        s += "Num Options: \n";
        for(Option o : options) {
            s += "     " + o + "\n";
        }
        return s;
    }
}