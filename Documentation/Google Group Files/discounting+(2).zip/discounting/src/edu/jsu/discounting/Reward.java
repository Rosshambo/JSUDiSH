package edu.jsu.discounting;

import java.text.DecimalFormat;

public class Reward {
    private static final int NUM_DECIMAL_PLACES = 4;
	private double value;
	private String type;
	
    private double round(double d, int numPlaces) {
        int scale = (int)Math.pow(10, numPlaces);
        int id = (int)(d * scale);
        return (double)id / (double)scale;
    }
    
	public Reward() {
		value = 0;
		type = "";
	}
	
	public Reward(double v, String t) {
		value = round(v, NUM_DECIMAL_PLACES);
		type = t;
	}
	
	public double getValue() { return value; }
	public void setValue(double v) { value = round(v, NUM_DECIMAL_PLACES); }
	public String getType() { return type; }
	public void setType(String t) { type = t; }
    
    public boolean equals(Reward r) {
        return (value == r.value && type.equals(r.type));
    }
	
	public String toString() {
		DecimalFormat format = new DecimalFormat("0.###");
		format.setMaximumFractionDigits(3);
        String s = String.valueOf(format.format(value)) + " " + type;
        if(value != 1) { 
            s += "s";
        }
        return s;
	}
}