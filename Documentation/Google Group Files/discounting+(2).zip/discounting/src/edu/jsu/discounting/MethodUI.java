package edu.jsu.discounting;

import javax.swing.JPanel;

import net.miginfocom.swing.MigLayout;

public abstract class MethodUI extends JPanel {
    protected Method method;

    public MethodUI(Method method) {
        this.setLayout(new MigLayout("fill"));
        this.method = method;        
    }

    public Method getMethod() { return method; }
    
    public abstract void begin();
}










