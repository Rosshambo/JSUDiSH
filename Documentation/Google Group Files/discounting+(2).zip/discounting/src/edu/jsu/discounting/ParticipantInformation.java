package edu.jsu.discounting;

import java.util.List;
import java.util.ArrayList;
import java.io.IOException;


public class ParticipantInformation {
    public enum Race { WHITE, BLACK, HISPANIC, PACIFIC_ISLANDER, AMERICAN_INDIAN, ASIAN };
    public enum Gender { MALE, FEMALE };
    private String id;
	private String firstName;
	private String lastName;
    private int age;
	private Race race;
    private Gender gender;

	public ParticipantInformation() {
        id = "";
        firstName = "";
        lastName = "";
        age = 0;
        race = Race.WHITE;
        gender = Gender.MALE;
	}	
	
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getFirstName() { return firstName; }
    public void setFirstName(String s) { firstName = s; }
    public String getLastName() { return lastName; }
    public void setLastName(String s) { lastName = s; }
    public int getAge() { return age; }
    public void setAge(int a) { age = a; }
    public Race getRace() { return race; }
    public void setRace(Race r) { race = r; }
    public Gender getGender() { return gender; }
    public void setGender(Gender g) { gender = g; }
    	
	public String toString() {
        String s = "ID: " + id + "\n";
        s += "Name: " + firstName + " " + lastName + "\n";
        s += "Age: " + age + "\n";
        s += "Race: " + race.toString() + "\n";
        s += "Gender: " + gender + "\n";
        return s;
	}
    
    public static int toCode(Race race) {
        if(race == Race.AMERICAN_INDIAN) return 1;
        else if(race == Race.ASIAN) return 2;
        else if(race == Race.BLACK) return 3;
        else if(race == Race.HISPANIC) return 4;
        else if(race == Race.PACIFIC_ISLANDER) return 5;
        else return 6;
    }

    public static int toCode(Gender gender) {
        if(gender == Gender.MALE) return 1;
        else return 2;
    }
    
    
    public static void main(String[] args) {
        ParticipantInformation p = new ParticipantInformation();
        System.out.println(p);
    }
}
