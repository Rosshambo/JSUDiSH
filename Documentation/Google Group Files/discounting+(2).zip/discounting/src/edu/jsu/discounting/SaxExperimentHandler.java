package edu.jsu.discounting;

import java.io.*;
import org.xml.sax.Attributes;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Validator;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.xml.sax.SAXException;



public class SaxExperimentHandler extends DefaultHandler {
	private Experiment experiment;
	private Investigator investigator;
	private Method method;
    private Scenario scenario;
	private Option option;
    private String rewardType;
	private String timeUnits;
	private String currentElement = null;
	
	public Experiment getExperiment() { return experiment; }
	
	private Time convertToTime(double value, String units) {
		Time t = new Time();
		t.setValue(value);
		if(units == null || units.equalsIgnoreCase("SECONDS")) {
			t.setType(Time.Type.SECONDS);
		}
		else if(units.equalsIgnoreCase("MINUTES")) {
			t.setType(Time.Type.MINUTES);
		}
		else if(units.equalsIgnoreCase("HOURS")) {
			t.setType(Time.Type.HOURS);
		}
		else if(units.equalsIgnoreCase("DAYS")) {
			t.setType(Time.Type.DAYS);
		}
		else if(units.equalsIgnoreCase("WEEKS")) {
			t.setType(Time.Type.WEEKS);
		}
		else if(units.equalsIgnoreCase("MONTHS")) {
			t.setType(Time.Type.MONTHS);
		}
		else if(units.equalsIgnoreCase("YEARS")) {
			t.setType(Time.Type.YEARS);
		}
		return t;
	}
	
	public void startElement(String namespaceURI, String localName, String qName, Attributes atts) {
		String name = localName;
		if(name.equalsIgnoreCase("CONCLUSION")) {
			currentElement = "CONCLUSION";
		}
		else if(name.equalsIgnoreCase("DA")) {
			currentElement = "DA";
			method = new DecreasingAdjustmentMethod();
		}
		else if(name.equalsIgnoreCase("DEPARTMENT")) {
			currentElement = "DEPARTMENT";	
		}
		else if(name.equalsIgnoreCase("DISTRIBUTION")) {
			currentElement = "DISTRIBUTION";
		}
		else if(name.equalsIgnoreCase("DL")) {
			currentElement = "DL";
			method = new DoubleLimitMethod();
		}
		else if(name.equalsIgnoreCase("EXPERIMENT")) {
			currentElement = "EXPERIMENT";
			experiment = new Experiment();
		}
		else if(name.equalsIgnoreCase("INSTRUCTIONS")) {
			currentElement = "INSTRUCTIONS";	
		}
		else if(name.equalsIgnoreCase("INVESTIGATOR")) {
			currentElement = "INVESTIGATOR";	
			investigator = new Investigator();
		}
		else if(name.equalsIgnoreCase("MC")) {
			currentElement = "MC";
			method = new MultipleChoiceMethod();
		}
		else if(name.equalsIgnoreCase("MAXREWARD")) {
			currentElement = "MAXREWARD";		
		}
		else if(name.equalsIgnoreCase("MAXTIME")) {
			currentElement = "MAXTIME";	
			timeUnits = atts.getValue("units");
		}
		else if(name.equalsIgnoreCase("MINREWARD")) {
			currentElement = "MINREWARD";		
		}
		else if(name.equalsIgnoreCase("NAME")) {
			currentElement = "NAME";		
		}
		else if(name.equalsIgnoreCase("NUMBER")) {
			currentElement = "NUMBER";		
		}
		else if(name.equalsIgnoreCase("NUMTRIALS")) {
			currentElement = "NUMTRIALS";		
		}
		else if(name.equalsIgnoreCase("OPTION")) {
			currentElement = "OPTION";
			option = new Option();
		}
		else if(name.equalsIgnoreCase("PERSONNEL")) {
			currentElement = "PERSONNEL";
		}
		else if(name.equalsIgnoreCase("RESPONSEDELAY")) {
			currentElement = "RESPONSEDELAY";		
			timeUnits = atts.getValue("units");
		}
		else if(name.equalsIgnoreCase("REWARD")) {
			currentElement = "REWARD";		
		}
		else if(name.equalsIgnoreCase("REWARDTYPE")) {
			currentElement = "REWARDTYPE";		
		}
		else if(name.equalsIgnoreCase("SCENARIO")) {
			currentElement = "SCENARIO";
            scenario = new Scenario();
		}
		else if(name.equalsIgnoreCase("TIME")) {
			currentElement = "TIME";		
			timeUnits = atts.getValue("units");
		}
		else if(name.equalsIgnoreCase("TITLE")) {
			currentElement = "TITLE";		
		}
	}
	
	public void endElement(String namespaceURI, String localName, String qName) {
		String name = localName;
		if(name.equalsIgnoreCase("CONCLUSION")) {
		
		}
		else if(name.equalsIgnoreCase("DA")) {
			experiment.addMethod(method);
			method = null;
		}
		else if(name.equalsIgnoreCase("DEPARTMENT")) {
			
		}
		else if(name.equalsIgnoreCase("DISTRIBUTION")) {

		}
		else if(name.equalsIgnoreCase("DL")) {
			experiment.addMethod(method);
			method = null;
		}
		else if(name.equalsIgnoreCase("EXPERIMENT")) {
			
		}
		else if(name.equalsIgnoreCase("INSTRUCTIONS")) {
			
		}
		else if(name.equalsIgnoreCase("INVESTIGATOR")) {
			experiment.addPersonnel(investigator);
			investigator = null;
		}
		else if(name.equalsIgnoreCase("MC")) {
			experiment.addMethod(method);
			method = null;
		}
		else if(name.equalsIgnoreCase("MAXREWARD")) {
			
		}
		else if(name.equalsIgnoreCase("MAXTIME")) {
			timeUnits = null;
		}
		else if(name.equalsIgnoreCase("MINREWARD")) {
			
		}
		else if(name.equalsIgnoreCase("NAME")) {
			
		}
		else if(name.equalsIgnoreCase("NUMBER")) {

		}
		else if(name.equalsIgnoreCase("OPTION")) {
			scenario.addOption(option);
			option = null;
		}
		else if(name.equalsIgnoreCase("PERSONNEL")) {
			
		}
		else if(name.equalsIgnoreCase("RESPONSEDELAY")) {
			timeUnits = null;
		}
		else if(name.equalsIgnoreCase("REWARD")) {

		}
		else if(name.equalsIgnoreCase("REWARDTYPE")) {

		}
		else if(name.equalsIgnoreCase("SCENARIO")) {
			method.addScenario(scenario);
            scenario = null;
		}
		else if(name.equalsIgnoreCase("TIME")) {
			timeUnits = null;
		}
		else if(name.equalsIgnoreCase("TITLE")) {

		}
	}
	
	public void characters(char ch[], int start, int length) {
		String value = new String(ch, start, length);
		value = value.trim();
		if(!value.equals("")) {
			if(currentElement.equalsIgnoreCase("CONCLUSION")) {
				experiment.setConclusion(value);
			}
			else if(currentElement.equalsIgnoreCase("DEPARTMENT")) {
				investigator.setDepartment(value);
			}
			else if(currentElement.equalsIgnoreCase("DISTRIBUTION")) {
				((MultipleChoiceMethod)method).setDistribution(value);
			}
			else if(currentElement.equalsIgnoreCase("INSTRUCTIONS")) {
				experiment.setInstructions(value);
			}
			else if(currentElement.equalsIgnoreCase("MAXTIME")) {
				double v = Double.parseDouble(value);
				Time t = convertToTime(v, timeUnits);
				method.setMaxTime(t);
			}
			else if(currentElement.equalsIgnoreCase("MAXREWARD")) {
				method.setMaxReward(new Reward(Double.parseDouble(value), rewardType));
			}
			else if(currentElement.equalsIgnoreCase("MINREWARD")) {
				method.setMinReward(new Reward(Double.parseDouble(value), rewardType));
			}
			else if(currentElement.equalsIgnoreCase("NAME")) {
                String[] name = value.split("\\W+", 2);
				investigator.setFirstName(name[0]);
				investigator.setLastName(name[1]);
			}
			else if(currentElement.equalsIgnoreCase("NUMBER")) {
				experiment.setNumber(Integer.parseInt(value));
			}
			else if(currentElement.equalsIgnoreCase("NUMTRIALS")) {
				((DecreasingAdjustmentMethod)method).setNumTrials(Integer.parseInt(value));
			}
			else if(currentElement.equalsIgnoreCase("RESPONSEDELAY")) {
				double v = Double.parseDouble(value);
				Time t = convertToTime(v, timeUnits);
				method.setResponseDelay(t);
			}
			else if(currentElement.equalsIgnoreCase("REWARD")) {
				option.setReward(new Reward(Double.parseDouble(value), rewardType));
			}
			else if(currentElement.equalsIgnoreCase("REWARDTYPE")) {
                rewardType = value;
			}
			else if(currentElement.equalsIgnoreCase("TIME")) {
				double v = Double.parseDouble(value);
				Time t = convertToTime(v, timeUnits);
				option.setTime(t);
			}
			else if(currentElement.equalsIgnoreCase("TITLE")) {
				experiment.setTitle(value);
			}
		}
	}
	
	
	
	public static void main(String[] args) throws SAXException, IOException {
        // 1. Lookup a factory for the W3C XML Schema language
        SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");

        // 2. Compile the schema. 
        // Here the schema is loaded from a java.io.File, but you could use 
        // a java.net.URL or a javax.xml.transform.Source instead.
        File schemaLocation = new File("../experiment.xsd");
        Schema schema = factory.newSchema(schemaLocation);

        // 3. Get a validator from the schema.
        Validator validator = schema.newValidator();

        // 4. Parse the document you want to check.
        Source source = new StreamSource("../experiment.xml");

        // 5. Check the document
        try {
            validator.validate(source);
            System.out.println("XML is valid.");
        }
        catch (SAXException ex) {
            System.out.println("XML is not valid because ");
            System.out.println(ex.getMessage());
        }  
           
        
     
		try {
			XMLReader parser = org.xml.sax.helpers.XMLReaderFactory.createXMLReader();

			// Create a new instance and register it with the parser
			SaxExperimentHandler contentHandler = new SaxExperimentHandler();
			parser.setContentHandler(contentHandler);

			// Don't worry about this for now -- we'll get to it later
			parser.parse("../experiment.xml");
			Experiment e = contentHandler.getExperiment();
			System.out.println(e);
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
        
	}
}
