package edu.jsu.discounting;


public class Investigator {
	private String firstName;
    private String lastName;
	private String department;
	
	public Investigator() {
		firstName = null;
		lastName = null;
		department = null;
	}
	
	public String getFirstName() { return firstName; }
	public void setFirstName(String s) { firstName = s; }
    public String getLastName() { return lastName; }
    public void setLastName(String s) { lastName = s; }
	public String getDepartment() { return department; }
	public void setDepartment(String s) { department = s; }	
    
    public String toString() {
        String f = (firstName != null)? firstName : "";
        String l = (lastName != null)? lastName : "";
        String d = (department != null)? department : "";
        String s = f;
        if(s.length() > 0 && l.length() > 0) s += " ";
        if(l.length() > 0) s += l;
        if(s.length() > 0 && d.length() > 0) s += ", ";
        if(d.length() > 0) s += d;
        return s;
    }
}