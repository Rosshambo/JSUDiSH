package edu.jsu.discounting;

import javax.swing.JPanel;
import javax.swing.JOptionPane;
import java.util.List;
import java.util.ArrayList;
import java.awt.CardLayout;
import org.xml.sax.XMLReader;
import javax.swing.JFrame;


public class ExperimentUI extends JPanel {
    private Experiment experiment;
	private ParticipantInformationUI participantInformationUI;
	private List<MethodUI> methodUI;
	private CardLayout cardLayout;
	private int currentSelection;
	
	public ExperimentUI(Experiment experiment) {
        this.experiment = experiment;
		participantInformationUI = new ParticipantInformationUI(experiment.getInstructions());
        
		methodUI = new ArrayList<MethodUI>();
        List<Method> methods = experiment.getMethods();
		for(Method m : methods) {
			if(m.getType() == Method.Type.DOUBLE_LIMIT) {
				methodUI.add(new DoubleLimitMethodUI((DoubleLimitMethod)m));
			}
			else if(m.getType() == Method.Type.DECREASING_ADJUSTMENT) {
				methodUI.add(new DecreasingAdjustmentMethodUI((DecreasingAdjustmentMethod)m));			
			}
			else if(m.getType() == Method.Type.MULTIPLE_CHOICE) {
				methodUI.add(new MultipleChoiceMethodUI((MultipleChoiceMethod)m));			
			}
		}
		cardLayout = new CardLayout();
		setLayout(cardLayout);
		this.add(participantInformationUI, String.valueOf(0));
		for(int i = 0; i < methodUI.size(); i++) {
			this.add(methodUI.get(i), String.valueOf(i + 1));
		}
		cardLayout.first(this);
		currentSelection = 0;
	}

	public void next() {
		if(currentSelection <= methodUI.size()) {
			currentSelection = (currentSelection + 1) % (methodUI.size() + 1);
			if(currentSelection > 0) {
                if(currentSelection == 1) {
                    experiment.setParticipantInformation(participantInformationUI.getParticipantInformation());
                }
				methodUI.get(currentSelection - 1).begin();
				cardLayout.show(this, String.valueOf(currentSelection));
			}
			else {
				endExperiment();
			}
		}
	}
	
	public void endExperiment() {
		JOptionPane.showMessageDialog(this.getTopLevelAncestor(), experiment.getConclusion(), "Experiment Finished", JOptionPane.INFORMATION_MESSAGE);
//        System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
//		System.out.println("Experiment complete: ");
//        System.out.println(experiment);
        DatabaseConnector.insert(experiment);
        ((DiscountingExperimentSystem)getTopLevelAncestor()).reset();
	}
	

    public static void main(String[] args) {
		try {
			XMLReader parser = org.xml.sax.helpers.XMLReaderFactory.createXMLReader();

			// Create a new instance and register it with the parser
			SaxExperimentHandler contentHandler = new SaxExperimentHandler();
			parser.setContentHandler(contentHandler);

			// Don't worry about this for now -- we'll get to it later
			parser.parse("../experiment.xml");
			Experiment e = contentHandler.getExperiment();
			System.out.println(e);
            ExperimentUI eui = new ExperimentUI(e);
            
    		JFrame window = new JFrame();
    		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    		window.add(eui);
    		window.pack();
    		window.setVisible(true);
        } 
		catch (Exception e) {
			e.printStackTrace();
		}
    
    }
}










