package edu.jsu.discounting;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;

import net.miginfocom.swing.MigLayout;


public class MultipleChoiceMethodUI extends MethodUI implements ActionListener {	
	private JButton confirmButton;
    private Scenario currentScenario;
    private ScenarioUI currentScenarioUI;
    private JPanel scenarioPanel;
		
	public MultipleChoiceMethodUI(MultipleChoiceMethod method) {
		super(method);
        currentScenario = method.getScenario(0);
        currentScenario.setResponseDelay(method.getResponseDelay());
        currentScenarioUI = new ScenarioUI(currentScenario);
        scenarioPanel = new JPanel();
        scenarioPanel.setLayout(new MigLayout("fill"));
        this.add(scenarioPanel, "center,grow,wrap");
        scenarioPanel.add(currentScenarioUI, "center,grow,wrap");
        
		confirmButton = new JButton("Confirm Choice");
		confirmButton.addActionListener(this);
		this.add(confirmButton, "center,span");	
	}

    public void begin() {
        currentScenarioUI.begin();
    }
    
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == confirmButton) {
            confirmButton.setEnabled(false);
            boolean optionSelected = currentScenarioUI.isOptionSelected();
			if(!optionSelected) {
				JOptionPane.showMessageDialog(this.getTopLevelAncestor(), "You must select an option.", "Incomplete Information", JOptionPane.ERROR_MESSAGE);
			}
			else {
                currentScenario.setChosenOption(currentScenarioUI.getSelectedOption());
                method.setIndifferencePoint(currentScenarioUI.getSelectedOption());
                ((ExperimentUI)this.getParent()).next();
			}
            confirmButton.setEnabled(false);
		}
	}
	
	
	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Method m;
		m = new MultipleChoiceMethod();
		m.setMinReward(new Reward(0.5, "junk"));
		m.setMaxReward(new Reward(20.0, "junk"));
		m.setMaxTime(new Time(30, Time.Type.SECONDS));
		m.setResponseDelay(new Time(1, Time.Type.SECONDS));
        ((MultipleChoiceMethod)m).setDistribution("blah distribution");
        Scenario s = new Scenario();
        s.addOption(new Option(new Reward(0.6, "junk"), new Time()));
        s.addOption(new Option(new Reward(0.9, "junk"), new Time(2, Time.Type.SECONDS)));
        s.addOption(new Option(new Reward(1.5, "junk"), new Time(8, Time.Type.SECONDS)));
        s.addOption(new Option(new Reward(2, "junk"), new Time(15, Time.Type.SECONDS)));
        s.addOption(new Option(new Reward(10, "junk"), new Time(25, Time.Type.SECONDS)));
        s.addOption(new Option(new Reward(20, "junk"), new Time(30, Time.Type.SECONDS)));
        m.addScenario(s);
        MethodUI mp = new MultipleChoiceMethodUI((MultipleChoiceMethod)m);
		window.add(mp);
		window.pack();
		window.setVisible(true);
		mp.begin();
	}
}










