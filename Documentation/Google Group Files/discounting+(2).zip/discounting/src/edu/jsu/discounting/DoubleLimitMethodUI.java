package edu.jsu.discounting;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Random;
import javax.swing.JFrame;


import net.miginfocom.swing.MigLayout;


/* 
Update algorithm taken from 
JOURNAL OF THE EXPERIMENTAL ANALYSIS OF BEHAVIOR, 77(2), 2002, pp. 129�146
WITHIN-SUBJECT COMPARISON OF REAL AND HYPOTHETICAL MONEY REWARDS IN DELAY DISCOUNTING
MATTHEW W. JOHNSON AND WARREN K. BICKEL
*/
public class DoubleLimitMethodUI extends MethodUI implements ActionListener {
	private Random random;
	private JButton confirmButton;
	private double outerUpperLimit;
	private double innerUpperLimit;
	private double innerLowerLimit;
	private double outerLowerLimit;
    private Scenario currentScenario;
    private ScenarioUI currentScenarioUI;
    private JPanel scenarioPanel;

	public DoubleLimitMethodUI(DoubleLimitMethod method) {
		super(method);
		random = new Random();
		outerUpperLimit = method.getMaxReward().getValue();
		innerUpperLimit = method.getMaxReward().getValue();
		innerLowerLimit = method.getMinReward().getValue();
		outerLowerLimit = method.getMinReward().getValue();
		double v = getRandomValue(outerLowerLimit, outerUpperLimit, 2);

        currentScenario = new Scenario();
        currentScenario.addOption(new Option(new Reward(v, method.getMinReward().getType()), new Time()));
        currentScenario.addOption(new Option(method.getMaxReward(), method.getMaxTime()));
        currentScenario.setResponseDelay(method.getResponseDelay());
        currentScenarioUI = new ScenarioUI(currentScenario);
        
        scenarioPanel = new JPanel();
        scenarioPanel.setLayout(new MigLayout("fill"));
        this.add(scenarioPanel, "center,grow,wrap");
        scenarioPanel.add(currentScenarioUI, "center,grow,wrap");
        
		confirmButton = new JButton("Confirm Choice");
		confirmButton.addActionListener(this);
		this.add(confirmButton, "center,span");	
	}

	private double getRandomValue(double min, double max, int percentIncrement) {
		int val = 100 / percentIncrement;
		int ip = random.nextInt(val + 1);
		double p = ((double)ip * (double)percentIncrement) / 100.0;	
		double range = max - min;
		double x = min + range * p;
		return x;
	}
    
    public void begin() {
        currentScenarioUI.begin();
    }
		
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == confirmButton) {
			confirmButton.setEnabled(false);
            boolean optionSelected = currentScenarioUI.isOptionSelected();
			if(!optionSelected) {
				JOptionPane.showMessageDialog(this.getTopLevelAncestor(), "You must select an option.", "Incomplete Information", JOptionPane.ERROR_MESSAGE);
			}
			else {
                OptionUI low = currentScenarioUI.getOptionUI(0);
                OptionUI high = currentScenarioUI.getOptionUI(1);
				double ssr = low.getOption().getReward().getValue();
				double llr = high.getOption().getReward().getValue();
				// SSR
				if(low.isSelected()) {
                    currentScenario.setChosenOption(low.getOption());
					if(ssr < innerUpperLimit) {
						outerUpperLimit = innerUpperLimit;
						innerUpperLimit = ssr;
						if(ssr < innerLowerLimit) {
							outerLowerLimit = method.getMinReward().getValue();
							innerLowerLimit = ssr;
						}
					}
					else {
						outerUpperLimit = ssr;
					}
				}
				// LLR
				else {
                    currentScenario.setChosenOption(high.getOption());
					if(ssr > innerLowerLimit) {
						outerLowerLimit = innerLowerLimit;
						innerLowerLimit = ssr;
						if(ssr > innerUpperLimit) {
							outerUpperLimit = llr;
							innerUpperLimit = ssr;
						}
					}
					else {
						outerLowerLimit = ssr;
					}
				}
				
                // Add the scenario to our bundle.
                method.addScenario(currentScenario);
                
				// Are we finished?
				if((outerUpperLimit - outerLowerLimit) <= 0.02 * method.getMaxReward().getValue()) {
					method.setIndifferencePoint(low.getOption());
					((ExperimentUI)this.getParent()).next();
				}
				else {
					double v = getRandomValue(outerLowerLimit, outerUpperLimit, 2);
                    currentScenario = new Scenario();
                    currentScenario.addOption(new Option(new Reward(v, method.getMinReward().getType()), new Time()));
                    currentScenario.addOption(new Option(method.getMaxReward(), method.getMaxTime()));
                    currentScenario.setResponseDelay(method.getResponseDelay());
                    scenarioPanel.removeAll();
                    currentScenarioUI = new ScenarioUI(currentScenario);
                    scenarioPanel.add(currentScenarioUI, "center,grow,wrap");
                    this.validate();
                    begin();
				}
			}
			confirmButton.setEnabled(true);
		}
	}
	
	
	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Method m;
		m = new DoubleLimitMethod();
		m.setMinReward(new Reward(0.5, "junk"));
		m.setMaxReward(new Reward(20.0, "junk"));
		m.setMaxTime(new Time(30, Time.Type.SECONDS));
		m.setResponseDelay(new Time(3, Time.Type.SECONDS));
		MethodUI mp = new DoubleLimitMethodUI((DoubleLimitMethod)m);
		window.add(mp);
		window.pack();
		window.setVisible(true);
		mp.begin();
	}
}










