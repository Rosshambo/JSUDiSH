package edu.jsu.discounting;


public class DoubleLimitMethod extends Method {
	public DoubleLimitMethod() {
		super(Method.Type.DOUBLE_LIMIT);
	}
}