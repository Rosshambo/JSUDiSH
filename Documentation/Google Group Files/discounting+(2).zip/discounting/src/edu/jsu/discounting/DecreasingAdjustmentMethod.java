package edu.jsu.discounting;


public class DecreasingAdjustmentMethod extends Method {
	private int numTrials;
	
	public DecreasingAdjustmentMethod() {
		super(Method.Type.DECREASING_ADJUSTMENT);
		numTrials = 0;
	}
	
	public int getNumTrials() { return numTrials; }
	public void setNumTrials(int nt) { numTrials = nt; }
        
    public String toString() {
        String s = super.toString();
        s += "Num Trials: " + numTrials + "\n";
        return s;
    }
    
}