package edu.jsu.discounting;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Vector;

import net.miginfocom.swing.MigLayout;


public class ParticipantInformationUI extends JPanel implements ActionListener {
    private ParticipantInformation participantInfo;
	private JTextField idTextField;
    private JTextField firstNameField;
    private JTextField lastNameField;
	private JComboBox ageComboBox;
    private JComboBox genderComboBox;
    private JComboBox raceComboBox;
	private JButton startButton;
	
	public ParticipantInformationUI(String instructions) {
		this.setLayout(new MigLayout("", "", ""));

		this.add(new JLabel(instructions), "wrap");
		this.add(new JLabel("ID"));
		idTextField = new JTextField(8);
		idTextField.addActionListener(this);
		this.add(idTextField, "wrap");
        
        this.add(new JLabel("First Name"));
        firstNameField = new JTextField(20);
        firstNameField.addActionListener(this);
        this.add(firstNameField, "wrap");        
        this.add(new JLabel("Last Name"));
        lastNameField = new JTextField(20);
        lastNameField.addActionListener(this);
        this.add(lastNameField, "wrap");
		
		Vector<Integer> ageVec = new Vector<Integer>();
		for(int i = 10; i <= 60; i++) {
			ageVec.add(i);
		}
		ageComboBox = new JComboBox(ageVec);
		ageComboBox.setEditable(false);
		ageComboBox.setSelectedIndex(8);
		this.add(new JLabel("Age"));
		this.add(ageComboBox, "wrap");
		
        ParticipantInformation.Gender[] genArray = {ParticipantInformation.Gender.MALE, ParticipantInformation.Gender.FEMALE};
        genderComboBox = new JComboBox(genArray);
        genderComboBox.setEditable(false);
		this.add(new JLabel("Gender"));
        this.add(genderComboBox, "wrap");
        
        ParticipantInformation.Race[] raceArray = {ParticipantInformation.Race.WHITE, 
                                                   ParticipantInformation.Race.BLACK, 
                                                   ParticipantInformation.Race.HISPANIC,
                                                   ParticipantInformation.Race.PACIFIC_ISLANDER,
                                                   ParticipantInformation.Race.AMERICAN_INDIAN,
                                                   ParticipantInformation.Race.ASIAN};
        raceComboBox = new JComboBox(raceArray);
        raceComboBox.setEditable(false);
		this.add(new JLabel("Race"));
        this.add(raceComboBox, "wrap");
		
		startButton = new JButton("Begin Experiment");
		startButton.addActionListener(this);
		this.add(startButton);
	}
	
	public ParticipantInformation getParticipantInformation() { 
        ParticipantInformation pi = new ParticipantInformation();
        pi.setId(idTextField.getText());
        pi.setFirstName(firstNameField.getText());
        pi.setLastName(lastNameField.getText());
        pi.setAge((Integer)ageComboBox.getSelectedItem());
        pi.setGender((ParticipantInformation.Gender)genderComboBox.getSelectedItem());
        pi.setRace((ParticipantInformation.Race)raceComboBox.getSelectedItem());
        return pi;
    }
		
	private String checkFields() {
		String message = null;
		if(idTextField.getText() != null) {
			String s = idTextField.getText().trim();
			if(s.length() == 9) {
				boolean isValid = true;
				for(int i = 0; i < s.length(); i++) {
					if(!Character.isDigit(s.charAt(i))) {
						isValid = false;
					}
				}
				if(!isValid) {
					return "The ID number is invalid.";
				}
			}
			else {
				return "The ID number is invalid.";
			}				
		}
        else {
            return "The ID number is invalid.";
        }
		if(firstNameField.getText() != null) {
            String s = firstNameField.getText().trim();
            if(s.length() == 0) {
                return "The first name is invalid.";
            }
        }
        else {
            return "The first name is invalid.";
        }
		if(lastNameField.getText() != null) {
            String s = lastNameField.getText().trim();
            if(s.length() == 0) {
                return "The last name is invalid.";
            }
        }
        else {
            return "The last name is invalid.";
        }

		return null;
	}
	
	public void actionPerformed(ActionEvent event) {
		String m = checkFields();
		if(m != null) {
			JOptionPane.showMessageDialog(this.getTopLevelAncestor(), m, "Invalid Information", JOptionPane.ERROR_MESSAGE);		
		}
		else {
            ((ExperimentUI)this.getParent()).next();
		}
	}
	
	
	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.add(new ParticipantInformationUI("Instructions go here"));
		window.pack();
		window.setVisible(true);
	}
}
