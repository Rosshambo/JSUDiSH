package edu.jsu.discounting;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import net.miginfocom.swing.MigLayout;

public class ScenarioUI extends JPanel {
    private final int TIMER_UPDATE_MILLIS = 1;
    private final String SCENARIO_PREAMBLE = "Would you prefer...";
    private Scenario scenario;
    private ButtonGroup optionGroup;
    private OptionUI[] optionButtons;

	
	public ScenarioUI(Scenario s) {
        scenario = s;
		this.setLayout(new MigLayout("fill"));
        this.add(new JLabel(SCENARIO_PREAMBLE, JLabel.CENTER), "grow,center,wrap");

        List<Option> options = scenario.getOptions();
        optionGroup = new ButtonGroup();
        if(options.size() > 0) {
            optionButtons = new OptionUI[options.size()];
            for(int i = 0; i < options.size(); i++) {
                optionButtons[i] = new OptionUI(options.get(i));
                optionGroup.add(optionButtons[i]);
                this.add(optionButtons[i], "grow,center,wrap");
            }
        }
	}

    public void begin() {
        enableOptions(false);
        optionGroup.clearSelection();
        TimerTask timerTask = new TimerTask() {
                                    private int elapsedMillis = 0;
                                    public void run() {
                                        long millis = scenario.getResponseDelay().convertToMillis();
                                        elapsedMillis += TIMER_UPDATE_MILLIS;
                                        if(elapsedMillis >= millis) {
                                            cancel();
                                            enableOptions(true);
                                        }										
                                    }};
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(timerTask, 0, TIMER_UPDATE_MILLIS);
	}
    
	public boolean isOptionSelected() {
		for(int i = 0; i < optionButtons.length; i++) {
			if(optionButtons[i].isSelected()) { 
				return true;
			}
		}
        return false;
	}
	
    public Option getSelectedOption() { 
        for(OptionUI oui : optionButtons) {
            if(oui.isSelected()) {
                return oui.getOption();
            }
        }
        return null; 
    }
    
    public OptionUI getOptionUI(int index) throws ArrayIndexOutOfBoundsException {
        return optionButtons[index];
    }
    
    public void enableOptions(boolean enable) {
        for(OptionUI o : optionButtons) {
            o.setEnabled(enable);
        }
    }
    
    
    public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Scenario s = new Scenario();
        s.addOption(new Option(new Reward(5, "star"), new Time()));
        s.addOption(new Option(new Reward(7, "star"), new Time(30, Time.Type.SECONDS)));
        s.addOption(new Option(new Reward(15, "star"), new Time(1, Time.Type.MINUTES)));
        s.setResponseDelay(new Time(3, Time.Type.SECONDS));
        ScenarioUI sui = new ScenarioUI(s);
		window.add(sui);
		window.pack();
		window.setVisible(true);
        sui.begin();
    }
}