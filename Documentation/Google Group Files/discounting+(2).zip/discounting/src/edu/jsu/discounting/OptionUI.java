package edu.jsu.discounting;

import javax.swing.JRadioButton;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import java.awt.geom.Rectangle2D;
import java.awt.FontMetrics;
import java.awt.Stroke;
import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Font;

public class OptionUI extends JRadioButton {
	private Option option;
	
    public OptionUI(Option opt) {
        option = opt;
        setFont(new Font("Verdana", Font.BOLD, 14));
        setText(option.toString()); 
        ImageIcon icon = new ImageIcon();
        setIcon(icon);
        setDisabledIcon(icon); 
    }
    
	public Option getOption() { return option; }
    
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D)g;
        g2D.setColor(getBackground());
        g2D.fillRect(0, 0, getWidth(), getHeight());
        
        if(isEnabled()) {
            g2D.setColor(Color.black);
        }
        else {
            g2D.setColor(Color.gray);        
        }

        g2D.setFont(this.getFont());//.deriveFont(16.0F));
        FontMetrics fm = g2D.getFontMetrics();
        String str = getText();
        Rectangle2D area = fm.getStringBounds(str, g2D);
        g2D.drawString(str, (int)(getWidth() - area.getWidth()) / 2,(int)(getHeight() + area.getHeight()) / 2);
        if(isSelected()) {
            Stroke stroke = g2D.getStroke();
            g2D.setStroke(new BasicStroke(4));//, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2D.setColor(Color.blue);
            g2D.drawRoundRect(0, 0, getWidth(), getHeight(), 4, 4);
            g2D.setStroke(stroke);
        }
    }

 
    public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Option o = new Option(new Reward(5, "star"), new Time());
        OptionUI oui = new OptionUI(o);
		window.add(oui);
		window.setSize(400, 400);
		window.setVisible(true);
    }
} 