import com.cloudgarden.speech.userinterface.*;
import javax.speech.*;
import javax.speech.recognition.*;
import java.io.*;
import java.net.*;
import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;

public class SomeApp extends JPanel implements StudyPalListener {

	StudyPal myPal;
	public SomeApp() {
        super(new GridBagLayout());
		setPreferredSize(new Dimension(1000, 800));		
		myPal = new StudyPal("c:/input.txt");
        //Add Components to this panel.
        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;

        c.fill = GridBagConstraints.HORIZONTAL;
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;

		this.add(myPal);
		myPal.addStudyPalListener(this);
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
				myPal.setupSpeech(myPal, "c:/input.txt");
            }
        });
		
//		myPal.createAndShowGUI("c:/input.txt");
	} //end of constructor

	public static void main(String[] args) {
		//Create and set up the window.
        JFrame frame = new JFrame("TextDemo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Add contents to the window.
		SomeApp app = new SomeApp();
        frame.add(app);
		
        //Display the window.
        frame.pack();
        frame.setVisible(true);	
	} //end main
	
	public void documentCompleted(StudyPalEvent e) {
		System.out.println("document completed!");
	}
	public void readingPaused(StudyPalEvent e) {
		System.out.println("reading paused!");
	}
	public void wordSkipped(StudyPalEvent e) {
		System.out.println("word skipped!");
	}
	
} //end class