DiSH Team,

Here is the (hopefully stable) version 1.0 of StudyPal.  I have included SomeApp.java, which is an example app that uses StudyPal, which is simply a JPanel.  Your program will have to work similarly. 

Since you don't have a CloudGarden license, you will have 30 days to run this example before it stops.  I don't think that's a problem since you're supposed to be done in a couple of weeks.

All of the .class files included are necessary, except for SomeApp.class, which is just an example.  I have only included the source of StudyPal for your curiosity.

REMEMBER to move the file "input.txt" to the C:/ drive, or you will get an error running the program.

Please let me know if you have any integration issues, and I'll be happy to oblige.

David Thornton