package edu.jsu.discounting;

import java.util.TimerTask;

public class EnableOptionsTask extends TimerTask {
	private MethodPanel methodPanel;
	private int updateMillis;
	private int elapsedMillis;
	
	public EnableOptionsTask(MethodPanel mp, int update) { 
		methodPanel = mp;
		updateMillis = update;
		elapsedMillis = 0;
	}
	
	public void run() {
		long millis = methodPanel.getMethod().getResponseDelay().convertToMillis();
		elapsedMillis += updateMillis;
		if(elapsedMillis >= millis) {
			cancel();
			methodPanel.enableOptions(true);
		}										
	}
}