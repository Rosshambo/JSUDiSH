package edu.jsu.discounting;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.Comment;
import org.w3c.dom.Text;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.util.Vector;
import java.io.IOException;


public class Experiment {
	private Vector<Investigator> personnel;
	private String title;
	private int number;
	private String instructions;
	private Vector<Method> methods;

	public Experiment() {
		personnel = new Vector<Investigator>();
		title = null;
		number = 1;
		instructions = null;
		methods = new Vector<Method>();
	}	
	
	public Vector<Investigator> getPersonnel() { return personnel; }
	public void addPersonnel(Investigator i) { personnel.add(i); }
	public int getNumPersonnel() { return personnel.size(); }
	public Investigator getPersonnel(int i) throws ArrayIndexOutOfBoundsException { return personnel.get(i); }	
	public String getTitle() { return title; }
	public void setTitle(String t) { title = t; }
	public int getNumber() { return number; }
	public void setNumber(int n) { number = n; }
	public String getInstructions() { return instructions; }
	public void setInstructions(String instruct) { instructions = instruct; }
	public Vector<Method> getMethods() { return methods; }
	public void addMethod(Method m) { methods.add(m); }
	public int getNumMethods() { return methods.size(); }
	public Method getMethod(int i) throws ArrayIndexOutOfBoundsException { return methods.get(i); }
	
	
	public void print() {
		System.out.println("Personnel: ");
		for(int i = 0; i < personnel.size(); i++) {
			System.out.println("   " + personnel.get(i).getName() + ", " + personnel.get(i).getDepartment());
		}
		System.out.println("Title: " + title);
		System.out.println("Number: " + number);
		System.out.println("Instructions: " + instructions);
		System.out.println("Num Methods: " + methods.size());
		for(int i = 0; i < methods.size(); i++) {
			if(methods.get(i).getType() == Method.Type.DOUBLE_LIMIT) {
				System.out.println("   Double Limit:");
				DoubleLimit x = (DoubleLimit)methods.get(i);
				System.out.print("      " + x.getMinValue() + " - " + x.getMaxValue() + " ");
				System.out.println(x.getValueType());
				System.out.println("      Max Time: " + x.getMaxTime().getValue() + " " + x.getMaxTime().getType());
				System.out.println("      Delay Time: " + x.getResponseDelay().getValue() + " " + x.getResponseDelay().getType());
			}
			else if(methods.get(i).getType() == Method.Type.DECREASING_ADJUSTMENT) {
				System.out.println("   Decreasing Adjustment:");
				DecreasingAdjustment x = (DecreasingAdjustment)methods.get(i);
				System.out.print("      " + x.getMinValue() + " - " + x.getMaxValue() + " ");
				System.out.println(x.getValueType());
				System.out.println("      Max Time: " + x.getMaxTime().getValue() + " " + x.getMaxTime().getType());
				System.out.println("      Delay Time: " + x.getResponseDelay().getValue() + " " + x.getResponseDelay().getType());
				System.out.println("      Num Trials: " + x.getNumTrials());
			}
			else if(methods.get(i).getType() == Method.Type.MULTIPLE_CHOICE) {
				System.out.println("   Multiple Choice:");
				MultipleChoice x = (MultipleChoice)methods.get(i);
				System.out.print("      " + x.getMinValue() + " - " + x.getMaxValue() + " ");
				System.out.println(x.getValueType());
				System.out.println("      Max Time: " + x.getMaxTime().getValue() + " " + x.getMaxTime().getType());
				System.out.println("      Delay Time: " + x.getResponseDelay().getValue() + " " + x.getResponseDelay().getType());
				System.out.println("      Distribution: " + x.getDistribution());
				System.out.println("      Items:");
				Vector<MultipleChoiceItem> v = x.getItems();
				for(MultipleChoiceItem item : v) {
					System.out.println("         Value: " + item.getValue() + "  Time: " + item.getTime().getValue() + " " + item.getTime().getType());
				}
			}
		}
	}
	
}
