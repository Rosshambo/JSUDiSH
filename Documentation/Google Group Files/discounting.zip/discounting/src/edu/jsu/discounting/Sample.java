package edu.jsu.discounting;


public class Sample {
	private double x;
	private double y;
	
	public Sample() {
		x = 0.0;
		y = 0.0;
	}
	
	public double getX() { return x; }
	public void setX(double d) { x = d; }
	public double getY() { return y; }
	public void setY(double d) { y = d; }
}