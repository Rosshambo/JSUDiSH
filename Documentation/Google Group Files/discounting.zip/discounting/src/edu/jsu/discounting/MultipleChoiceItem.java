package edu.jsu.discounting;


public class MultipleChoiceItem {
	private double value;
	private Time time;
	
	public MultipleChoiceItem() {
		value = 0.0;
		time = null;
	}
	
	public MultipleChoiceItem(double v, Time t) {
		value = v;
		time = t;
	}
	
	public double getValue() { return value; }
	public void setValue(double v) { value = v; }
	public Time getTime() { return time; }
	public void setTime(Time t) { time = t; }
	
}