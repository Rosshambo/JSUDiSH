package edu.jsu.discounting;


public class Time {
	public enum Type { SECONDS, MINUTES, HOURS, DAYS, WEEKS, MONTHS, YEARS };
	private double value;
	private Type type;
	
	public Time() {
		value = 0;
		type = Type.SECONDS;
	}
	
	public Time(double v, Type t) {
		value = v;
		type = t;
	}
	
	public double getValue() { return value; }
	public void setValue(double v) { value = v; }
	public Type getType() { return type; }
	public void setType(Type t) { type = t; }
	
	public String toString() {
		if(value > 0) {
			String s = String.valueOf(value);
			s += " ";
			switch(type) {
				case SECONDS: s += "seconds"; break;
				case MINUTES: s += "minutes"; break;
				case HOURS: s += "hours"; break;
				case DAYS: s += "days"; break;
				case WEEKS: s += "weeks"; break;
				case MONTHS: s += "months"; break;
				case YEARS: s += "years"; break;
			}
			return s;
		}
		else {
			return "now";
		}
	}
	
	public long convertToMillis() {
		long scale = 0;
		switch(type) {
			case SECONDS: scale = 1000; break;
			case MINUTES: scale = 60000; break;
			case HOURS: scale = 3600000; break;
			case DAYS: scale = 86400000; break;
			case WEEKS: scale = 604800000; break;
			case MONTHS: scale = 999999999; break;
			case YEARS: scale = 999999999; break;
		}
		return (long)(value * scale);
	}
}