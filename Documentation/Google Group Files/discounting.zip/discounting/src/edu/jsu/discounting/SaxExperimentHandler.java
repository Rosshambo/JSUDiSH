package edu.jsu.discounting;

import java.io.*;
import org.xml.sax.Attributes;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;


public class SaxExperimentHandler extends DefaultHandler {
	private Experiment experiment;
	private Investigator investigator;
	private Method method;
	private MultipleChoiceItem mcItem;
	private String timeUnits;
	private String currentElement = null;
	
	public Experiment getExperiment() { return experiment; }
	
	private Time convertToTime(double value, String units) {
		Time t = new Time();
		t.setValue(value);
		if(units == null || units.equalsIgnoreCase("SECONDS")) {
			t.setType(Time.Type.SECONDS);
		}
		else if(units.equalsIgnoreCase("MINUTES")) {
			t.setType(Time.Type.MINUTES);
		}
		else if(units.equalsIgnoreCase("HOURS")) {
			t.setType(Time.Type.HOURS);
		}
		else if(units.equalsIgnoreCase("DAYS")) {
			t.setType(Time.Type.DAYS);
		}
		else if(units.equalsIgnoreCase("WEEKS")) {
			t.setType(Time.Type.WEEKS);
		}
		else if(units.equalsIgnoreCase("MONTHS")) {
			t.setType(Time.Type.MONTHS);
		}
		else if(units.equalsIgnoreCase("YEARS")) {
			t.setType(Time.Type.YEARS);
		}
		return t;
	}
	
	public void startElement(String namespaceURI, String localName, String qName, Attributes atts) {
		String name = localName;
		if(name.equalsIgnoreCase("CHOICES")) {
			currentElement = "CHOICES";
		}
		else if(name.equalsIgnoreCase("DA")) {
			currentElement = "DA";
			method = new DecreasingAdjustment();
		}
		else if(name.equalsIgnoreCase("DEPARTMENT")) {
			currentElement = "DEPARTMENT";	
		}
		else if(name.equalsIgnoreCase("DISTRIBUTION")) {
			currentElement = "DISTRIBUTION";
		}
		else if(name.equalsIgnoreCase("DL")) {
			currentElement = "DL";
			method = new DoubleLimit();
		}
		else if(name.equalsIgnoreCase("EXPERIMENT")) {
			currentElement = "EXPERIMENT";
			experiment = new Experiment();
		}
		else if(name.equalsIgnoreCase("INSTRUCTIONS")) {
			currentElement = "INSTRUCTIONS";	
		}
		else if(name.equalsIgnoreCase("INVESTIGATOR")) {
			currentElement = "INVESTIGATOR";	
			investigator = new Investigator();
		}
		else if(name.equalsIgnoreCase("ITEM")) {
			currentElement = "ITEM";
			mcItem = new MultipleChoiceItem();
		}
		else if(name.equalsIgnoreCase("MC")) {
			currentElement = "MC";
			method = new MultipleChoice();
		}
		else if(name.equalsIgnoreCase("MAXVALUE")) {
			currentElement = "MAXVALUE";		
		}
		else if(name.equalsIgnoreCase("MAXTIME")) {
			currentElement = "MAXTIME";	
			timeUnits = atts.getValue("units");
		}
		else if(name.equalsIgnoreCase("MINVALUE")) {
			currentElement = "MINVALUE";		
		}
		else if(name.equalsIgnoreCase("NAME")) {
			currentElement = "NAME";		
		}
		else if(name.equalsIgnoreCase("NUMBER")) {
			currentElement = "NUMBER";		
		}
		else if(name.equalsIgnoreCase("NUMTRIALS")) {
			currentElement = "NUMTRIALS";		
		}
		else if(name.equalsIgnoreCase("PERSONNEL")) {
			currentElement = "PERSONNEL";
		}
		else if(name.equalsIgnoreCase("RESPONSEDELAY")) {
			currentElement = "RESPONSEDELAY";		
			timeUnits = atts.getValue("units");
		}
		else if(name.equalsIgnoreCase("TIME")) {
			currentElement = "TIME";		
			timeUnits = atts.getValue("units");
		}
		else if(name.equalsIgnoreCase("TITLE")) {
			currentElement = "TITLE";		
		}
		else if(name.equalsIgnoreCase("VALUE")) {
			currentElement = "VALUE";		
		}
		else if(name.equalsIgnoreCase("VALUETYPE")) {
			currentElement = "VALUETYPE";		
		}
	}
	
	public void endElement(String namespaceURI, String localName, String qName) {
		String name = localName;
		if(name.equalsIgnoreCase("CHOICES")) {
			
		}
		else if(name.equalsIgnoreCase("DA")) {
			experiment.addMethod(method);
			method = null;
		}
		else if(name.equalsIgnoreCase("DEPARTMENT")) {
			
		}
		else if(name.equalsIgnoreCase("DISTRIBUTION")) {

		}
		else if(name.equalsIgnoreCase("DL")) {
			experiment.addMethod(method);
			method = null;
		}
		else if(name.equalsIgnoreCase("EXPERIMENT")) {
			
		}
		else if(name.equalsIgnoreCase("INSTRUCTIONS")) {
			
		}
		else if(name.equalsIgnoreCase("INVESTIGATOR")) {
			experiment.addPersonnel(investigator);
			investigator = null;
		}
		else if(name.equalsIgnoreCase("ITEM")) {
			((MultipleChoice)method).addItem(mcItem);
			mcItem = null;
		}
		else if(name.equalsIgnoreCase("MC")) {
			experiment.addMethod(method);
			method = null;
		}
		else if(name.equalsIgnoreCase("MAXVALUE")) {
			
		}
		else if(name.equalsIgnoreCase("MAXTIME")) {
			timeUnits = null;
		}
		else if(name.equalsIgnoreCase("MINVALUE")) {
			
		}
		else if(name.equalsIgnoreCase("NAME")) {
			
		}
		else if(name.equalsIgnoreCase("NUMBER")) {

		}
		else if(name.equalsIgnoreCase("PERSONNEL")) {
			
		}
		else if(name.equalsIgnoreCase("RESPONSEDELAY")) {
			timeUnits = null;
		}
		else if(name.equalsIgnoreCase("TIME")) {
			timeUnits = null;
		}
		else if(name.equalsIgnoreCase("TITLE")) {

		}
		else if(name.equalsIgnoreCase("VALUE")) {

		}
		else if(name.equalsIgnoreCase("VALUETYPE")) {

		}
	}
	
	public void characters(char ch[], int start, int length) {
		String value = new String(ch, start, length);
		value = value.trim();
		if(!value.equals("")) {
			if(currentElement.equalsIgnoreCase("DEPARTMENT")) {
				investigator.setDepartment(value);
			}
			else if(currentElement.equalsIgnoreCase("DISTRIBUTION")) {
				((MultipleChoice)method).setDistribution(value);
			}
			else if(currentElement.equalsIgnoreCase("INSTRUCTIONS")) {
				experiment.setInstructions(value);
			}
			else if(currentElement.equalsIgnoreCase("MAXTIME")) {
				double v = Double.parseDouble(value);
				Time t = convertToTime(v, timeUnits);
				method.setMaxTime(t);
			}
			else if(currentElement.equalsIgnoreCase("MAXVALUE")) {
				method.setMaxValue(Double.parseDouble(value));
			}
			else if(currentElement.equalsIgnoreCase("MINVALUE")) {
				method.setMinValue(Double.parseDouble(value));
			}
			else if(currentElement.equalsIgnoreCase("NAME")) {
				investigator.setName(value);
			}
			else if(currentElement.equalsIgnoreCase("NUMBER")) {
				experiment.setNumber(Integer.parseInt(value));
			}
			else if(currentElement.equalsIgnoreCase("NUMTRIALS")) {
				((DecreasingAdjustment)method).setNumTrials(Integer.parseInt(value));
			}
			else if(currentElement.equalsIgnoreCase("RESPONSEDELAY")) {
				double v = Double.parseDouble(value);
				Time t = convertToTime(v, timeUnits);
				method.setResponseDelay(t);
			}
			else if(currentElement.equalsIgnoreCase("TIME")) {
				double v = Double.parseDouble(value);
				Time t = convertToTime(v, timeUnits);
				mcItem.setTime(t);
			}
			else if(currentElement.equalsIgnoreCase("TITLE")) {
				experiment.setTitle(value);
			}
			else if(currentElement.equalsIgnoreCase("VALUE")) {
				mcItem.setValue(Double.parseDouble(value));
			}
			else if(currentElement.equalsIgnoreCase("VALUETYPE")) {
				method.setValueType(value);
			}
		}
	}
	
	
	
	public static void main(String[] args) {
		try {
			XMLReader parser = org.xml.sax.helpers.XMLReaderFactory.createXMLReader();

			// Create a new instance and register it with the parser
			SaxExperimentHandler contentHandler = new SaxExperimentHandler();
			parser.setContentHandler(contentHandler);

			// Don't worry about this for now -- we'll get to it later
			parser.parse("experiment.xml");
			Experiment e = contentHandler.getExperiment();
			e.print();
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
