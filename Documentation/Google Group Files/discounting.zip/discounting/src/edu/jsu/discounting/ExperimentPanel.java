package edu.jsu.discounting;

import javax.swing.JPanel;
import javax.swing.JOptionPane;
import java.util.Vector;
import java.awt.CardLayout;


public class ExperimentPanel extends JPanel {
	private CardLayout cardLayout;
	private ParticipantLoginPanel loginPanel;
	private Vector<Method> methods;
	private Vector<MethodPanel> methodPanels;
	private int currentSelection;
	
	
	public ExperimentPanel(String instructions, Vector<Method> methods) {
		loginPanel = new ParticipantLoginPanel(instructions);
		this.methods = methods;
		methodPanels = new Vector<MethodPanel>();
		for(Method m : methods) {
			if(m.getType() == Method.Type.DOUBLE_LIMIT) {
				methodPanels.add(new DoubleLimitMethodPanel(m));
			}
			else if(m.getType() == Method.Type.DECREASING_ADJUSTMENT) {
				methodPanels.add(new DecreasingAdjustmentMethodPanel(m));			
			}
			else if(m.getType() == Method.Type.MULTIPLE_CHOICE) {
				methodPanels.add(new MultipleChoiceMethodPanel(m));			
			}
		}
		cardLayout = new CardLayout();
		setLayout(cardLayout);
		add(loginPanel, String.valueOf(0));
		for(int i = 0; i < methodPanels.size(); i++) {
			add(methodPanels.get(i), String.valueOf(i + 1));
		}
		cardLayout.first(this);
		currentSelection = 0;
	}

	public void next() {
		if(currentSelection <= methodPanels.size()) {
			currentSelection = (currentSelection + 1) % (methodPanels.size() + 1);
			if(currentSelection > 0) {
				methodPanels.get(currentSelection - 1).reset();
				methodPanels.get(currentSelection - 1).begin();
				cardLayout.show(this, String.valueOf(currentSelection));
			}
			else {
				endExperiment();
			}
		}
	}
	
	public void endExperiment() {
		JOptionPane.showMessageDialog(this.getTopLevelAncestor(), "The experiment is complete.", "Experiment Finished", JOptionPane.INFORMATION_MESSAGE);
		System.out.println("Experiment complete: " + loginPanel.getParticipantId());
		loginPanel.resetValues();
		cardLayout.next(this);
	}
	
	
}










