package edu.jsu.discounting;


public class DoubleLimit extends Method {
	
	public DoubleLimit() {
		super(Method.Type.DOUBLE_LIMIT);
	}
	
}