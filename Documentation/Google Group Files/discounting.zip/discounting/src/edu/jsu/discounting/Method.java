package edu.jsu.discounting;

public class Method {
	public enum Type {DOUBLE_LIMIT, DECREASING_ADJUSTMENT, MULTIPLE_CHOICE};
	protected Type type;
	protected String valueType;
	protected double minValue;
	protected double maxValue;
	protected Time maxTime;
	protected Time responseDelay;
	
	public Method(Type type) {
		this.type = type;
		valueType = null;
		minValue = 0;
		maxValue = 0;
		maxTime = null;
		responseDelay = null;
	}
	
	public Type getType() { return type; }
	public void setType(Type t) { type = t; }
	public String getValueType() { return valueType; }
	public void setValueType(String s) { valueType = s; }
	public double getMinValue() { return minValue; }
	public void setMinValue(double v) { minValue = v; }
	public double getMaxValue() { return maxValue; }
	public void setMaxValue(double v) { maxValue = v; }
	public Time getMaxTime() { return maxTime; }
	public void setMaxTime(Time t) { maxTime = t; }
	public Time getResponseDelay() { return responseDelay; }
	public void setResponseDelay(Time t) { responseDelay = t; }
}