package edu.jsu.discounting;


public class DecreasingAdjustment extends Method {
	private int numTrials;
	
	public DecreasingAdjustment() {
		super(Method.Type.DECREASING_ADJUSTMENT);
		numTrials = 0;
	}
	
	public int getNumTrials() { return numTrials; }
	public void setNumTrials(int nt) { numTrials = nt; }
}