package edu.jsu.discounting;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Random;
import javax.swing.JFrame;


import net.miginfocom.swing.MigLayout;


/* 
Update algorithm taken from 
JOURNAL OF THE EXPERIMENTAL ANALYSIS OF BEHAVIOR, 77(2), 2002, pp. 129�146
WITHIN-SUBJECT COMPARISON OF REAL AND HYPOTHETICAL MONEY REWARDS IN DELAY DISCOUNTING
MATTHEW W. JOHNSON AND WARREN K. BICKEL
*/
public class DoubleLimitMethodPanel extends MethodPanel implements ActionListener {
	private Random random;
	private JButton confirmButton;
	private double outerUpperLimit;
	private double innerUpperLimit;
	private double innerLowerLimit;
	private double outerLowerLimit;

	public DoubleLimitMethodPanel(Method method) {
		super(method);
		random = new Random();
		outerUpperLimit = method.getMaxValue();
		innerUpperLimit = method.getMaxValue();
		innerLowerLimit = method.getMinValue();
		outerLowerLimit = method.getMinValue();
		initialize();
	}

	private double getRandomValue(double min, double max, int percentIncrement) {
		int val = 100 / percentIncrement;
		int ip = random.nextInt(val + 1);
		double p = ((double)ip * (double)percentIncrement) / 100.0;	
		double range = max - min;
		double x = min + range * p;
		return x;
	}
	
	private void initialize() {
		DoubleLimit dl = (DoubleLimit)method;
		this.add(new JLabel(OPTION_PREAMBLE, JLabel.CENTER), "span,center,wrap");
		options = new DiscountingOption[2];
		double v = getRandomValue(outerLowerLimit, outerUpperLimit, 2);
		options[0] = new DiscountingOption(v, method.getValueType(), new Time());
		options[1] = new DiscountingOption(dl.getMaxValue(), method.getValueType(), dl.getMaxTime());
		optionGroup = new ButtonGroup();
		optionGroup.add(options[0]);
		optionGroup.add(options[1]);
		this.add(options[0]);
		this.add(options[1], "wrap");
		confirmButton = new JButton("Confirm Choice");
		confirmButton.addActionListener(this);
		this.add(confirmButton, "center,span");	
		enableOptions(false);
	}

	public void reset() {
		outerUpperLimit = method.getMaxValue();
		innerUpperLimit = method.getMaxValue();
		innerLowerLimit = method.getMinValue();
		outerLowerLimit = method.getMinValue();
		double v = getRandomValue(outerLowerLimit, outerUpperLimit, 2);
		options[0].setValue(v);
		options[1].setValue(method.getMaxValue());
		enableOptions(false);
	}
	
	
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == confirmButton) {
			confirmButton.setEnabled(false);
			String message = validateForm();
			if(message != null) {
				JOptionPane.showMessageDialog(this.getTopLevelAncestor(), message, "Incomplete Information", JOptionPane.ERROR_MESSAGE);
			}
			else {
				double ssr = options[0].getValue();
				double llr = options[1].getValue();
				// SSR
				if(options[0].isSelected()) {
					if(ssr < innerUpperLimit) {
						outerUpperLimit = innerUpperLimit;
						innerUpperLimit = ssr;
						if(ssr < innerLowerLimit) {
							outerLowerLimit = method.getMinValue();
							innerLowerLimit = ssr;
						}
					}
					else {
						outerUpperLimit = ssr;
					}
				}
				// LLR
				else {
					if(ssr > innerLowerLimit) {
						outerLowerLimit = innerLowerLimit;
						innerLowerLimit = ssr;
						if(ssr > innerUpperLimit) {
							outerUpperLimit = llr;
							innerUpperLimit = ssr;
						}
					}
					else {
						outerLowerLimit = ssr;
					}
				}
				
				// Are we finished?
				if((outerUpperLimit - outerLowerLimit) <= 0.02 * method.getMaxValue()) {
					double indifferencePoint = ssr;
					System.out.println("Done with IP = " + indifferencePoint);
					((ExperimentPanel)this.getParent()).next();
				}
				else {
					double v = getRandomValue(outerLowerLimit, outerUpperLimit, 2);
					options[0].setValue(v);
					begin();
				}
			}
			confirmButton.setEnabled(true);
		}
	}
	
	
	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Method m;
		m = new DoubleLimit();
		m.setMinValue(0.5);
		m.setMaxValue(20.0);
		m.setMaxTime(new Time(30, Time.Type.SECONDS));
		m.setResponseDelay(new Time(3, Time.Type.SECONDS));
		MethodPanel mp = new DoubleLimitMethodPanel(m);
		window.add(mp);
		window.pack();
		window.setVisible(true);
		mp.begin();
	}
}










