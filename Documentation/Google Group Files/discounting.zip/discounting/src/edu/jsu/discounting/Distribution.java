package edu.jsu.discounting;

import java.util.Vector;

public class Distribution {
	private Vector<Sample> samples;
	
	public Distribution() {
		samples = new Vector<Sample>();
	}
	
	public Vector<Sample> getSamples() { return samples; }
	public void addSample(Sample s) { samples.add(s); }
	public Sample getSample(int i) { return samples.get(i); }
}