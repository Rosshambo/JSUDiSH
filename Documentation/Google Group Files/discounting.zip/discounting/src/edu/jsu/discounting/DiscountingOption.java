package edu.jsu.discounting;

import javax.swing.JRadioButton;
import java.text.DecimalFormat;

public class DiscountingOption extends JRadioButton {
	private double value;
	private String valueType;
	private Time time;
	private DecimalFormat format;
	
	public DiscountingOption(double v, String valType, Time t) {
		format = new DecimalFormat("#.0");
		format.setMaximumFractionDigits(1);
		value = v;
		valueType = valType;
		time = t;
		resetText();
	}
	
	private void resetText() {
		String valString = format.format(value) + " " + valueType;
		if(value != 1) {
			valString += "s";
		}
		if(time.getValue() == 0) {
			setText(valString + " now");
		}
		else {
			setText(valString + " in " + time);
		}	
	}
	
	public double getValue() { return value; }
	public void setValue(double v) {
		value = v;
		resetText();
	}
	public String getValueType() { return valueType; }
	public void setValueType(String t) { 
		valueType = t; 
		resetText();
	}
	public Time getTime() { return time; }
	public void setTime(Time t) {
		time = t;
		resetText();
	}
} 