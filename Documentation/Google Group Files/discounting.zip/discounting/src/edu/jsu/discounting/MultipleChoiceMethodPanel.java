package edu.jsu.discounting;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.util.Vector;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;


import net.miginfocom.swing.MigLayout;


public class MultipleChoiceMethodPanel extends MethodPanel implements ActionListener {
	
	private JButton confirmButton;
		
	public MultipleChoiceMethodPanel(Method method) {
		super(method);
		initialize();
	}

	private void initialize() {
		MultipleChoice mc = (MultipleChoice)method;
		this.add(new JLabel(OPTION_PREAMBLE, JLabel.CENTER), "span,center,wrap");
		optionGroup = new ButtonGroup();
		options = new DiscountingOption[mc.getNumItems()];
		Vector<MultipleChoiceItem> v = mc.getItems();
		for(int i = 0; i < v.size(); i++) {
			options[i] = new DiscountingOption(v.get(i).getValue(), method.getValueType(), v.get(i).getTime());
			optionGroup.add(options[i]);
			this.add(options[i], "span,center,wrap");
		}
		confirmButton = new JButton("Confirm Choice");
		confirmButton.addActionListener(this);
		this.add(confirmButton, "center,span");	
		enableOptions(false);
	}

	public void reset() {
		MultipleChoice mc = (MultipleChoice)method;
		Vector<MultipleChoiceItem> v = mc.getItems();
		for(int i = 0; i < v.size(); i++) {
			options[i].setValue(v.get(i).getValue());
		}
		enableOptions(false);
	}
	
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == confirmButton) {
			String message = validateForm();
			if(message != null) {
				JOptionPane.showMessageDialog(this.getTopLevelAncestor(), message, "Incomplete Information", JOptionPane.ERROR_MESSAGE);
			}
			else {
				int i = 0;
				boolean found = false;
				while(!found && i < options.length) {
					if(options[i].isSelected()) {
						found = true;
					}
					else {
						i++;
					}
				}
				double indifferencePoint = options[i].getValue();
				System.out.println("Done  IP = " + indifferencePoint);
				((ExperimentPanel)this.getParent()).next();
			}
		}
	}
	
	
	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Method m;
		m = new MultipleChoice();
		m.setMinValue(0.5);
		m.setMaxValue(20.0);
		m.setMaxTime(new Time(30, Time.Type.SECONDS));
		m.setResponseDelay(new Time(3, Time.Type.SECONDS));
		((MultipleChoice)m).addItem(new MultipleChoiceItem(0.1, new Time(30, Time.Type.SECONDS)));
		((MultipleChoice)m).addItem(new MultipleChoiceItem(0.5, new Time(30, Time.Type.SECONDS)));
		((MultipleChoice)m).addItem(new MultipleChoiceItem(1.0, new Time(30, Time.Type.SECONDS)));
		((MultipleChoice)m).addItem(new MultipleChoiceItem(3.0, new Time(30, Time.Type.SECONDS)));
		
		MethodPanel mp = new MultipleChoiceMethodPanel(m);
		window.add(mp);
		window.pack();
		window.setVisible(true);
		mp.begin();
	}
}










