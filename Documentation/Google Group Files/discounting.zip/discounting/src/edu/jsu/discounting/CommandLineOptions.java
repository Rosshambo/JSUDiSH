package edu.jsu.discounting;

import java.io.File;
import org.kohsuke.args4j.Option;

public class CommandLineOptions {

	@Option(name="-name", usage="Sets a name")
	public String name;
	
	public File file;

	@Option(name="-file", usage="Sets a file if it exists")
	public void setFile(File f) { 
		if (f.exists()) file = f; 
	} 
}
   