package edu.jsu.discounting;

import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class MultipleChoice extends Method {
	private Vector<MultipleChoiceItem> item;
	private String distribution;
	
	public MultipleChoice() {
		super(Method.Type.MULTIPLE_CHOICE);
		item = new Vector<MultipleChoiceItem>();
		distribution = null;
	}
	
	public Vector<MultipleChoiceItem> getItems() { return item; }
	public void addItem(MultipleChoiceItem i) { item.add(i); }
	public int getNumItems() { return item.size(); }
	public MultipleChoiceItem getItem(int i) throws ArrayIndexOutOfBoundsException { return item.get(i); }	
	public String getDistribution() { return distribution; }
	public void setDistribution(String d) { distribution = d; }
}