package edu.jsu.discounting;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.CardLayout;
import java.util.Vector;

import net.miginfocom.swing.MigLayout;


public class ParticipantLoginPanel extends JPanel implements ActionListener {
	private String participantId;
	private int participantAge;
	private boolean maleParticipant;
	private JTextField idTextField;
	private JComboBox ageComboBox;
	private ButtonGroup genderButtonGroup;
	private JRadioButton[] genderRadioButton;
	private JButton startButton;
	
	public ParticipantLoginPanel(String instructions) {
		this.setLayout(new MigLayout("", "", ""));

		this.add(new JLabel(instructions), "wrap");
		this.add(new JLabel("Student ID"), "wrap");
		idTextField = new JTextField(8);
		idTextField.addActionListener(this);
		this.add(idTextField, "wrap");
		
		Vector<Integer> ageVec = new Vector<Integer>();
		for(int i = 10; i <= 60; i++) {
			ageVec.add(i);
		}
		ageComboBox = new JComboBox(ageVec);
		ageComboBox.setEditable(false);
		ageComboBox.setSelectedIndex(8);
		this.add(new JLabel("Age"), "span 2");
		this.add(new JLabel("Gender"), "span 2, wrap");
		this.add(ageComboBox, "span 2");
		
		genderRadioButton = new JRadioButton[2];
		genderRadioButton[0] = new JRadioButton("Male");
		genderRadioButton[1] = new JRadioButton("Female");
		genderButtonGroup = new ButtonGroup();
		genderButtonGroup.add(genderRadioButton[0]);
		genderButtonGroup.add(genderRadioButton[1]);
		this.add(genderRadioButton[0]);
		this.add(genderRadioButton[1], "wrap");
		
		startButton = new JButton("Begin Experiment");
		startButton.addActionListener(this);
		this.add(startButton);
	}
	
	public String getParticipantId() { return participantId; }
	public int getParticipantAge() { return participantAge; }
	public boolean isParticipantMale() { return maleParticipant; }
	
	public void resetValues() {
		participantId = null;
		idTextField.setText("");
		participantAge = 0;
		ageComboBox.setSelectedIndex(8);
		maleParticipant = false;
		genderButtonGroup.clearSelection();
	}
	
	
	private String validateForm() {
		String message = null;
		if(idTextField.getText() != null) {
			String s = idTextField.getText().trim();
			if(s.length() == 9) {
				boolean isValid = true;
				for(int i = 0; i < s.length(); i++) {
					if(!Character.isDigit(s.charAt(i))) {
						isValid = false;
					}
				}
				if(!isValid) {
					message = "The student number is invalid.";
					return message;
				}
			}
			else {
				message = "The student number is invalid.";
				return message;
			}				
		}
		if(!genderRadioButton[0].isSelected() && !genderRadioButton[1].isSelected()) {
			message = "You must select a gender.";
			return message;
		}

		return message;
	}
	
	public void actionPerformed(ActionEvent event) {
		String m = validateForm();
		if(m != null) {
			JOptionPane.showMessageDialog(this.getTopLevelAncestor(), m, "Invalid Information", JOptionPane.ERROR_MESSAGE);		
		}
		else {
			participantId = idTextField.getText().trim();
			participantAge = (Integer)ageComboBox.getSelectedItem();
			if(genderRadioButton[0].isSelected()) {
				maleParticipant = true;
			}
			else {
				maleParticipant = false;
			}
			
			((ExperimentPanel)this.getParent()).next();
		}
	}
	
	
	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.add(new ParticipantLoginPanel("Instructions go here"));
		window.pack();
		window.setVisible(true);
	}
}
