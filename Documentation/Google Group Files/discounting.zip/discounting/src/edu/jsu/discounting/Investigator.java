package edu.jsu.discounting;


public class Investigator {
	private String name;
	private String department;
	
	public Investigator() {
		name = null;
		department = null;
	}
	
	public String getName() { return name; }
	public void setName(String s) { name = s; }
	public String getDepartment() { return department; }
	public void setDepartment(String s) { department = s; }	
}