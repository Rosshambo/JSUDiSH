package edu.jsu.discounting;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;


import net.miginfocom.swing.MigLayout;


public class DecreasingAdjustmentMethodPanel extends MethodPanel implements ActionListener {
	private JButton confirmButton;
	private double adjustment;
	private int numTrials;
	private int maxNumTrials;
		
	public DecreasingAdjustmentMethodPanel(Method method) {
		super(method);
		adjustment = 0;
		numTrials = 0;
		initialize();
	}

	private void initialize() {
		DecreasingAdjustment da = (DecreasingAdjustment)method;
		maxNumTrials = da.getNumTrials();
		this.add(new JLabel(OPTION_PREAMBLE, JLabel.CENTER), "span,center,wrap");
		options = new DiscountingOption[2];
		adjustment = (da.getMaxValue() - da.getMinValue()) / 2.0;
		options[0] = new DiscountingOption(da.getMinValue() + adjustment, method.getValueType(), new Time());
		options[1] = new DiscountingOption(da.getMaxValue(), method.getValueType(), da.getMaxTime());
		optionGroup = new ButtonGroup();
		optionGroup.add(options[0]);
		optionGroup.add(options[1]);
		this.add(options[0]);
		this.add(options[1], "wrap");		
		confirmButton = new JButton("Confirm Choice");
		confirmButton.addActionListener(this);
		this.add(confirmButton, "center,span");	
		enableOptions(false);
	}
	
	public void reset() {
		DecreasingAdjustment da = (DecreasingAdjustment)method;
		maxNumTrials = da.getNumTrials();
		numTrials = 0;
		adjustment = (da.getMaxValue() - da.getMinValue()) / 2.0;
		options[0].setValue(da.getMinValue() + adjustment);
		options[1].setValue(da.getMaxValue());
		enableOptions(false);	
	}
	
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == confirmButton) {
			String message = validateForm();
			if(message != null) {
				JOptionPane.showMessageDialog(this.getTopLevelAncestor(), message, "Incomplete Information", JOptionPane.ERROR_MESSAGE);
			}
			else {
				double lower = options[0].getValue();
				double upper = options[1].getValue();
				double value;
				if(options[0].isSelected()) {
					value = lower - adjustment / 2.0;
					if(value < method.getMinValue()) { value = method.getMinValue(); }
				}
				else {
					value = lower + adjustment / 2.0;
					if(value > method.getMaxValue()) { value = method.getMaxValue(); }
				}
				adjustment /= 2.0;
				numTrials++;
				if(numTrials >= maxNumTrials) {
					double indifferencePoint = value;
					adjustment = 0;
					System.out.println("Done  IP = " + indifferencePoint);
					((ExperimentPanel)this.getParent()).next();
				}
				else {
					options[0].setValue(value);
					begin();
				}
			}
		}
	}
	
	
	public static void main(String[] args) {
		JFrame window = new JFrame();
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Method m;
		m = new DecreasingAdjustment();
		m.setMinValue(0.5);
		m.setMaxValue(20.0);
		m.setMaxTime(new Time(30, Time.Type.SECONDS));
		m.setResponseDelay(new Time(2, Time.Type.SECONDS));
		((DecreasingAdjustment)m).setNumTrials(5);
		MethodPanel mp = new DecreasingAdjustmentMethodPanel(m);
		window.add(mp);
		window.pack();
		window.setVisible(true);
		mp.begin();
	}
}










