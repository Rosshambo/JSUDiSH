package edu.jsu.discounting;

import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.CmdLineException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.Vector;
import org.xml.sax.XMLReader;



public class DiscountingExperimentSystem extends JFrame implements ActionListener {
	private JMenuBar menuBar;
	private JMenu adminMenu;
	private JMenuItem loadExperimentMenuItem;
	private JMenuItem stopExperimentMenuItem;
	private Experiment currentExperiment;
	private String adminPassword;
	private ExperimentPanel experimentPanel;
	private JPanel mainContentPanel;

	public DiscountingExperimentSystem(String adminPwd) {
		adminPassword = adminPwd;
		
		setTitle("Discounting in Study Habits");
		menuBar = new JMenuBar();
		adminMenu = new JMenu("Administration");
		adminMenu.setMnemonic(KeyEvent.VK_A);
		adminMenu.getAccessibleContext().setAccessibleDescription("Administrative functions like loading and stopping experiments");
		menuBar.add(adminMenu);
		
		loadExperimentMenuItem = new JMenuItem("Load Experiment", KeyEvent.VK_L);
		loadExperimentMenuItem.addActionListener(this);
		loadExperimentMenuItem.getAccessibleContext().setAccessibleDescription("Loads an experiment from an XML file");
		adminMenu.add(loadExperimentMenuItem);

		stopExperimentMenuItem = new JMenuItem("Stop Experiment", KeyEvent.VK_S);
		stopExperimentMenuItem.addActionListener(this);
		stopExperimentMenuItem.getAccessibleContext().setAccessibleDescription("Stops an experiment in progress");
		adminMenu.add(stopExperimentMenuItem);
		
		this.setJMenuBar(menuBar);
		
		currentExperiment = null;
		mainContentPanel = new JPanel();
		mainContentPanel.setPreferredSize(new Dimension(600, 500));
		this.add(mainContentPanel);
	}

	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == loadExperimentMenuItem) {
			String password = JOptionPane.showInputDialog(this, "Please enter the administration password.", "Enter Password", JOptionPane.QUESTION_MESSAGE); 
			if(password != null && password.equals(adminPassword)) {
				JFileChooser chooser = new JFileChooser();
				FileNameExtensionFilter filter = new FileNameExtensionFilter("XML Experiment Files", "xml");
				chooser.setFileFilter(filter);
				int returnVal = chooser.showOpenDialog(this);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					try {
						XMLReader parser = org.xml.sax.helpers.XMLReaderFactory.createXMLReader();
						SaxExperimentHandler contentHandler = new SaxExperimentHandler();
						parser.setContentHandler(contentHandler);
						parser.parse(chooser.getSelectedFile().toURI().toString());
						currentExperiment = contentHandler.getExperiment();
						currentExperiment.print();
						
						experimentPanel = new ExperimentPanel(currentExperiment.getInstructions(), currentExperiment.getMethods());
						mainContentPanel.add(experimentPanel);
						this.pack();
					}
					catch(Exception e) {
						e.printStackTrace();
					}
				}				
			}
			else {
				JOptionPane.showMessageDialog(this, "The password was invalid.", "Invalid Password!", JOptionPane.ERROR_MESSAGE);
			}
		}
		else if(event.getSource() == stopExperimentMenuItem) {
			String password = JOptionPane.showInputDialog(this, "Please enter the administration password.", "Enter Password", JOptionPane.QUESTION_MESSAGE); 
			if(password != null && password.equals(adminPassword)) {
				System.out.println("STOP THE EXPERIMENT");
			}
			else {
				JOptionPane.showMessageDialog(this, "The password was invalid.", "Invalid Password!", JOptionPane.ERROR_MESSAGE);
			}
		}
	}



	public static void main(String args[]) {
	
		// Command-line argments...
		CommandLineOptions clo = new CommandLineOptions();
		CmdLineParser parser = new CmdLineParser(clo);
		try {
			parser.parseArgument(args);
			System.out.println("Name is " + clo.name);
		} 
		catch (CmdLineException e) {
			// handling of wrong arguments
			System.err.println(e.getMessage());
			parser.printUsage(System.err);
		}
		
		
		// Database stuff...
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/discounting", "root", "");
			
			if(!con.isClosed()) {
				System.out.println("Successfully connected to " + "MySQL server using TCP/IP...");
			}
		}	
		catch(Exception e) {
			System.err.println("Exception: " + e.getMessage());
		} 
		finally {
			try {
				if(con != null) {
					con.close();
				}
			} 
			catch(SQLException e) {}
		}
		
		
		// Window...
		DiscountingExperimentSystem window = new DiscountingExperimentSystem("none");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.pack();
//		window.setExtendedState(JFrame.MAXIMIZED_BOTH | window.getExtendedState());
		window.setResizable(true);
		window.setVisible(true);
	}
}