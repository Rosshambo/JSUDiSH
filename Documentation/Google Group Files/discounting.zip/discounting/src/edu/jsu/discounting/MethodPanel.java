package edu.jsu.discounting;

import javax.swing.JPanel;
import javax.swing.ButtonGroup;
import java.util.Timer;
import java.util.TimerTask;


import net.miginfocom.swing.MigLayout;


public abstract class MethodPanel extends JPanel {
	protected final int TIMER_UPDATE_MILLIS = 1;
	protected final String OPTION_PREAMBLE = "Would you prefer...";
	
	protected DiscountingOption[] options;
	protected ButtonGroup optionGroup;
	protected Method method;
	protected Timer timer;
	protected TimerTask timerTask;
		
	public MethodPanel(Method method) {
		this.setLayout(new MigLayout("", "", ""));
		this.method = method;
		timer = new Timer();
	}

	protected void enableOptions(boolean b) {
		for(int i = 0; i < options.length; i++) {
			options[i].setEnabled(b);
		}
	}
	
	protected String validateForm() {
		boolean isOptionSelected = false;
		for(int i = 0; i < options.length; i++) {
			if(options[i].isSelected()) { 
				isOptionSelected = true;
			}
		}
		if(!isOptionSelected) {
			return "You must select an option.";
		}
		else {
			return null;
		}
	}
	
	public void begin() {
		enableOptions(false);
		optionGroup.clearSelection();
		timerTask = new EnableOptionsTask(this, TIMER_UPDATE_MILLIS);
		timer.scheduleAtFixedRate(timerTask, 0, TIMER_UPDATE_MILLIS);
	}
	
	public abstract void reset();
	
	public Method getMethod() { return method; }
	
}










