import java.sql.*;

class database { 
  
  public static Connection conn = null;
  public static int validation = 0;
  
  //**********************************************************************************************************
  public static void main(String[] args)
  {
    
  }
  //**********************************************************************************************************
  
  
  //***********************************************************************************************************
    //CONNECT TO THE DATABASE
 public static void connect() { 
        try { 
  

   String userName = "root";
   String password = "fundop";
   String url = "jdbc:mysql://localhost/videos";
   Class.forName ("com.mysql.jdbc.Driver").newInstance ();
   conn = DriverManager.getConnection (url, userName, password);


   //PRINT OUT CONNECTION CONFIRMATION
   //System.out.println ("Database connection established");

        } catch (Exception e) { 
            System.err.println("Got an exception! "); 
            System.err.println(e.getMessage()); 
        } 
    } 
 //END OF DATABASE CONNECTION
 //************************************************************************************************************
 
 
 //***********************************************************************************************************
 //INSERT QUERY INTO DATABASE
 public static void insert (String q){
   String query = q;
   
   //CONNECT TO THE DATABASE
   connect();
   
   try { 
       Statement stmt = conn.createStatement(); 
       stmt.executeUpdate(query);
       System.out.println(query + "Executed Successfully");
   } catch (Exception e) { 
     System.err.println("Got an exception! "); 
     System.err.println(e.getMessage()); 
   } 
   
 }
 //END OF INSERT QUERY
 //*************************************************************************************************************
 
 
 //***********************************************************************************************************
 //RETRIEVE QUERY INFO FROM DATABASE
 public static void retrieve(String q){
   String query = q;
   
   //CONNECT TO THE DATABASE
   connect();
   
   //RETRIEVE THE DATA
   try { 
     
       Statement stmt = conn.createStatement(); 
       ResultSet rs; 
       rs = stmt.executeQuery(query); 
       while ( rs.next() ) { 
           String username = rs.getString("username"); 
           String password = rs.getString("password"); 
           String first_name = rs.getString("first_name"); 
           String last_name = rs.getString("last_name"); 
           String department = rs.getString("department"); 
           String privilege = rs.getString("privilege"); 
           
       } 
       
   } catch (Exception e) { 
     System.err.println("Got an exception! "); 
     System.err.println(e.getMessage()); 
   } 
   
 }
 //END OF RETRIEVE QUERY
 //*************************************************************************************************************
 
 
 //***********************************************************************************************************
 //VERIFY USER LOGIN & STATUS
 public static int verifyLogin(String u, String p){
   String user = u;
   String pass = p;
   
   //CONNECT TO THE DATABASE
   connect();
   
   //RETRIEVE THE DATA
   try { 
     
     validation = 0;
     
       Statement stmt = conn.createStatement(); 
       ResultSet rs; 
       rs = stmt.executeQuery("SELECT username, password, privilege FROM users WHERE username = '" + user + "'"); 
       while ( rs.next() ) { 
           String username = rs.getString("username"); 
           String password = rs.getString("password"); 
           String privilege = rs.getString("privilege"); 
           
           if (user.equals(username)){
             if(privilege.equals("a")){
             validation = 1;
             }
             if(privilege.equals("e")){
               validation = 2;
             }
           }
           
       } 
       
   } catch (Exception e) { 
     System.err.println("Got an exception! "); 
     System.err.println(e.getMessage()); 
   } 
   
   return validation;

 }
 //END OF VERIFY USER LOGIN & STATUS
 //*************************************************************************************************************
 
 
   // Convert password to string*********************************************************
        public static String convertPassword(char[] cPassword)
        {
                // Declare variables
                String strRet = new String("");
                
                // Go through each character
                for (int i = 0; i < cPassword.length; i++)
                {
                        strRet += cPassword[i];
                }
                
                return strRet;
        }
        //********************************************************************************
}