import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DBUI
{
 
  public static void main(String[] args)
  {

  }
  
  public static void create()
  {
    JFrame frame = new JFrame("DISH ADMIN PANEL");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JTabbedPane tab = new JTabbedPane();
    frame.add(tab, BorderLayout.CENTER);
    
    //**************************************************************************
    //TAB 1 ********************************************************************
    //**************************************************************************
    JPanel tab1 = new JPanel(new GridLayout(1,2));
    JPanel userdetails = new JPanel(new GridLayout(9,2));
    
    //USER DETAILS PANEL CONTROL
    JLabel usernameT;
    usernameT = new JLabel("Username: ");
    JTextField username;
    username = new JTextField();
    
    JLabel passwordT;
    passwordT = new JLabel("Password: ");
    JTextField password;
    password = new JTextField();
    
    JLabel confirmpasswordT;
    confirmpasswordT = new JLabel("Confirm Password: ");
    JTextField confirmpassword;
    confirmpassword = new JTextField();
    
    JLabel firstnameT;
    firstnameT = new JLabel("First Name: ");
    JTextField firstname;
    firstname = new JTextField();
    
    JLabel lastnameT;
    lastnameT = new JLabel("Last Name: ");
    JTextField lastname;
    lastname = new JTextField();
    
    JLabel departmentT;
    departmentT = new JLabel("Department: ");
    JTextField department;
    department = new JTextField();
    
    JLabel privilegeT;
    privilegeT = new JLabel("Privilege: ");
    
    JPanel privilege = new JPanel(new GridLayout(1,2));
    
    ButtonGroup group = new ButtonGroup();
    
    JRadioButton option1 = new JRadioButton("Admin", true);
    group.add(option1);
    privilege.add(option1);
    
    JRadioButton option2 = new JRadioButton("Experimenter", false);
    group.add(option2);
    privilege.add(option2);
    
    JButton adduser = new JButton("Submit");
    
    
    //ADD USER DETAILS PANEL CONTROLS
    userdetails.add(usernameT);
    userdetails.add(username);
    userdetails.add(passwordT);
    userdetails.add(password);
    userdetails.add(confirmpasswordT);
    userdetails.add(confirmpassword);
    userdetails.add(firstnameT);
    userdetails.add(firstname);
    userdetails.add(lastnameT);
    userdetails.add(lastname);
    userdetails.add(departmentT);
    userdetails.add(department);
    userdetails.add(privilegeT);
    userdetails.add(privilege);
    userdetails.add(adduser);
    
    //VIEW USERS PANEL
    JPanel viewusers = new JPanel(new GridLayout(3,1));
    
    //VIEW USERS PANEL CONTROLS
    JList sampleJList;
    JTextField valueField;
    
    String[] entries = { "Logan Moore", "Lori Liles", "Tony Teem",
                         "Jaleesa Elston", "Tonya Burton", "Andrew Peil", 
                         "Dr. Thornton", "Dr. Garrett", "Michael Bolton", 
                         "Michael Jackson", "George Michael", "Prince" };
    sampleJList = new JList(entries);
    sampleJList.setVisibleRowCount(4);
    Font displayFont = new Font("Serif", Font.BOLD, 18);
    sampleJList.setFont(displayFont);
    //sampleJList.addListSelectionListener(new ValueReporter());
    JScrollPane listPane = new JScrollPane(sampleJList);
    
    JButton newuser = new JButton("New User");
    JButton removeuser = new JButton("Remove User");
    
    
    //ADD VIEW USERS PANEL CONTROLS
    viewusers.add(listPane);
    JPanel userbuttons = new JPanel(new GridLayout(1,2));
    userbuttons.add(newuser);
    userbuttons.add(removeuser);
    viewusers.add(userbuttons);
    
    
    
    //ADD USER DETAILS PANEL TO TAB1 PANEL
    tab1.add(viewusers);
    tab1.add(userdetails);
    tab.add("User Admin", tab1);
    
    //==========================================================================
    
    
    //**************************************************************************
    //TAB 2 ********************************************************************
    //**************************************************************************
    JPanel tab2 = new JPanel(new GridLayout(2,4));
    
    //DEFINE PANELS
    JPanel optionsbox = new JPanel(new GridLayout(1,1));
    JPanel optionsbox2 = new JPanel(new GridLayout(1,1));    
    JPanel leftright = new JPanel(new GridLayout(2,1));
    JPanel resultsfilter = new JPanel(new GridLayout(2,1));    
    JPanel filtersome = new JPanel(new GridLayout(1,3));  
    
    //ADD OPTIONS BOX
    JList optionsbox1;
    JTextField optionsbox1valuefield;
    String[] optionbox1entries = { "Logan Moore", "Lori Liles", "Tony Teem",
                         "Jaleesa Elston", "Tonya Burton", "Andrew Peil", 
                         "Dr. Thornton", "Dr. Garrett", "Michael Bolton", 
                         "Michael Jackson", "George Michael", "Prince" };
    sampleJList = new JList(entries);
    sampleJList.setVisibleRowCount(4);
    Font optionsbox1displayFont = new Font("Serif", Font.BOLD, 18);
    sampleJList.setFont(displayFont);
    //sampleJList.addListSelectionListener(new ValueReporter());
    JScrollPane optionsboxz1 = new JScrollPane(sampleJList);
    optionsbox.add(optionsboxz1);
    //END OF OPTIONS BOX
    
    
    //ADD OPTIONSBOX2
    JList optionsboxa;
    JTextField optionsbox2valuefield;
    String[] optionbox2entries = { "" };
    sampleJList = new JList(optionbox2entries);
    sampleJList.setVisibleRowCount(4);
    Font optionsbox2displayFont = new Font("Serif", Font.BOLD, 18);
    sampleJList.setFont(displayFont);
    //sampleJList.addListSelectionListener(new ValueReporter());
    JScrollPane optionsboxz2 = new JScrollPane(sampleJList);
    //END OF OPTIONS BOX 2
    
    
    //RESULTS FILTER PANE
    JPanel filterallsome = new JPanel(new GridLayout(1,2));
    ButtonGroup filterallsome2 = new ButtonGroup();
    JRadioButton all = new JRadioButton("Retrieve All The Results", true);
    group.add(all);
    filterallsome.add(all);
    JRadioButton some = new JRadioButton("Filter The Results", false);
    group.add(some);
    filterallsome.add(some);
    

        
    //FILTER SOME PANEL
    //WHERE JLABEL
    JLabel where;
    where = new JLabel("Where: ");
    filtersome.add(where);
    
    
    //OPTIONS
    String[] options = { "Age", "Race", "Gender", "First Name", "Last Name" };
    JComboBox optionsl = new JComboBox(options);
    optionsl.setSelectedIndex(4);
    //options.addActionListener(this);
    filtersome.add(optionsl);
    
    //OPERATORS
    String[] operators = { "<", ">", "=", "!="};
    JComboBox ops = new JComboBox(operators);
    ops.setSelectedIndex(3);
    //options.addActionListener(this);
    filtersome.add(ops);
    
    //FILTER TEXT CRITERIA
    JTextField criteria;
    criteria = new JTextField();
    filtersome.add(criteria);
    //END OF FILTER SOME PANEL
    
    
    //ADD PANES TO RESULTS FILTER
    resultsfilter.add(filterallsome);
    resultsfilter.add(filtersome);
    
   
    JButton runquery;
    runquery = new JButton("Run Query");
    
    JButton addtolibrary;
    addtolibrary = new JButton("Add Query To Library");
    
    JLabel queryname;
    queryname = new JLabel("Query Name: ");
    
    JTextField querynameT;
    querynameT = new JTextField();
    
    
    
    //LEFT RIGHT PANE
    JButton left = new JButton("<<");
    leftright.add(left);
    JButton right = new JButton(">>");
    leftright.add(right);  
    //END OF LEFT RIGHT PANE
    
    //ADD TAB 2 TO THE TABBED PANE
    tab.add("Query Builder", tab2);
    
    //ADD PANELS TO TAB 2
    tab2.add(optionsbox);
    tab2.add(leftright);
    tab2.add(optionsboxz2);
    tab2.add(resultsfilter);
    tab2.add(runquery);
    tab2.add(addtolibrary);
    tab2.add(queryname);
    tab2.add(querynameT);
    
    
    //==========================================================================
    
    //**************************************************************************
    //TAB 3 ********************************************************************
    //**************************************************************************
    JPanel tab3 = new JPanel(new GridLayout(3,1));
    JPanel querynamepanel = new JPanel(new GridLayout(1,2));  
    JPanel querybuttons = new JPanel(new GridLayout(1,2));      
    
    //ADD TAB 3 TO THE TABBED PANE
    tab.add("Advanced Query Builder", tab3);
    
    
    //TEXTAREA
    JTextArea textarea;
    textarea = new JTextArea();
    //================================
    
    //QUERYNAME
    JLabel querynamepanelL;
    querynamepanelL = new JLabel("Query Name: ");
    
    JTextField querynamepanelT;
    querynamepanelT = new JTextField();
    
    querynamepanel.add(querynamepanelL);
    querynamepanel.add(querynamepanelT);
    //===================================
    
    //QUERY BUTTONS
    JButton runqueryb;
    runqueryb = new JButton("Run Query");
    JButton addtolib;
    addtolib = new JButton("Add Query To Library");
    querybuttons.add(runqueryb);
    querybuttons.add(addtolib);
    //===============================================
    
    //ADD PANELS TO TAB 3
    tab3.add(textarea);
    tab3.add(querynamepanel);
    tab3.add(querybuttons);
    //===============================================
    
    
    
    
    //==========================================================================
    
    //**************************************************************************
    //TAB 4 ********************************************************************
    //**************************************************************************
    JPanel tab4 = new JPanel(new GridLayout(4,1));
    JPanel qlpane = new JPanel(new GridLayout(1,1));   
    JPanel cbpane = new JPanel(new GridLayout(2,5));   
    JPanel cvpane = new JPanel(new GridLayout(1,1));   
    JPanel lbpane = new JPanel(new GridLayout(1,2));   
    
    //ADD TAB 4 TO THE TABBED PANE
    tab.add("Query Library", tab4);
    
    //QUERYLISTBOX PANE====================================
    
    //ADD QUERIES LIST----------------------------------
    JList qlbox;
    JTextField qlboxfield;
    String[] qlboxentries = { "Red Haired Ladies", "Caucasian Males", "Hispanic Women Under 40", " ", " ", " ", " ", " ", " ", " ", " ",
                         };
    sampleJList = new JList(qlboxentries);
    sampleJList.setVisibleRowCount(4);
    Font qldisplayFont = new Font("Serif", Font.BOLD, 18);
    sampleJList.setFont(displayFont);
    //sampleJList.addListSelectionListener(new ValueReporter());
    JScrollPane qlboxscrollpane = new JScrollPane(sampleJList);
    qlpane.add(qlboxscrollpane);
    //END OF QUERIES LIST------------------------------
    
    
    //==================================================
    
    //CODE BUTTONS PANE
    
    JLabel space1;
    space1 = new JLabel("");
    JLabel space2;
    space2 = new JLabel("");
    JLabel space3;
    space3 = new JLabel("");
    JLabel space4;
    space4 = new JLabel("");
    JLabel space5;
    space5 = new JLabel("");
    JLabel space6;
    space6 = new JLabel(" -6- ");    
    JLabel space7;
    space7 = new JLabel(" -7- ");
    JLabel space8;
    space8 = new JLabel(" -8- ");
    
    
    JButton hidecode;
    hidecode = new JButton("Hide Code");
    
    JButton copycode;
    copycode = new JButton("Copy Code");
    
    cbpane.add(space1);
    cbpane.add(space2);
    cbpane.add(space3);
    cbpane.add(space4);
    cbpane.add(space5);
    
    cbpane.add(space6);
    cbpane.add(hidecode);
    cbpane.add(space7);
    cbpane.add(copycode);
    cbpane.add(space8);
    
//    cbpane.add(space1);
//    cbpane.add(space1);
//    cbpane.add(space1);
//    cbpane.add(space1);
//    cbpane.add(space1);
    
      
    //==================================================
    
    //CODE VIEWER PANE
    
    JTextArea cvbox;
    cvbox = new JTextArea();
    
    cvpane.add(cvbox);
    
    //==================================================
    
    //LIBRARY BUTTONS PANE
    
    JButton runquery3;
    runquery3 = new JButton("Run Query");
    
    JButton deletequery;
    deletequery = new JButton("Delete Query From Library");
    
    lbpane.add(runquery3);
    lbpane.add(deletequery);
    
    //==================================================
    
    tab4.add(qlpane);
    tab4.add(cbpane);
    tab4.add(cvpane);
    tab4.add(lbpane);
    
    //==========================================================================
    
    //**************************************************************************
    //TAB 5 ********************************************************************
    //**************************************************************************
    JPanel tab5 = new JPanel(new GridLayout(1,1)); 
    
    //ADD TAB 5 TO THE TABBED PANE
    tab.add("Results", tab5);
        
    
    //==========================================================================
    
    frame.setSize(800,600);
    frame.setVisible(true);
  }
  
}